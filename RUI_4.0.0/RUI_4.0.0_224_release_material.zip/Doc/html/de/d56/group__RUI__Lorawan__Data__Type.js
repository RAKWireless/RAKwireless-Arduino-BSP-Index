var group__RUI__Lorawan__Data__Type =
[
    [ "RAKLoraP2P", "d8/da8/classRAKLoraP2P.html", [
      [ "RAKLoraP2P", "de/d56/group__RUI__Lorawan__Data__Type.html#ga16017aceba9b637180e264c4e410c802", null ],
      [ "iqInver", "de/d56/group__RUI__Lorawan__Data__Type.html#gadbe5448b21c73b7771f0f63bb657053b", null ],
      [ "syncword", "de/d56/group__RUI__Lorawan__Data__Type.html#ga652a2465541aa497f68e1e4281890073", null ],
      [ "rfFrequency", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7bd30bc7a5f4ba3fe21d34a2828caaa0", null ],
      [ "txOutputPower", "de/d56/group__RUI__Lorawan__Data__Type.html#ga1e27bec3900515642d8d8e5758af484e", null ],
      [ "bandwidth", "de/d56/group__RUI__Lorawan__Data__Type.html#gafd12eaaa8c52eb3fc5343aac8ee957e7", null ],
      [ "speradingFactor", "de/d56/group__RUI__Lorawan__Data__Type.html#gae4020faa1144f6df1b792462cd64b783", null ],
      [ "codingrate", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7dc745794c81f0e6cd15bb98449b71c5", null ],
      [ "preambleLength", "de/d56/group__RUI__Lorawan__Data__Type.html#ga3c3e21b522152e8f90c588fbb2b78667", null ],
      [ "symbolTimeout", "de/d56/group__RUI__Lorawan__Data__Type.html#ga903790f622e90e8754dc6d9391666f51", null ],
      [ "fixLengthPayload", "de/d56/group__RUI__Lorawan__Data__Type.html#gad4e43af408e69c81bb81b66c758f3269", null ]
    ] ],
    [ "fixLengthPayload", "d4/db5/classRAKLoraP2P_1_1fixLengthPayload.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5a0ac596ad458f81229cb3b8542c99a7", null ]
    ] ],
    [ "symbolTimeout", "da/d95/classRAKLoraP2P_1_1symbolTimeout.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaf27fd3bf5132a7da2c6d48d11605beee", null ]
    ] ],
    [ "preambleLength", "dd/d50/classRAKLoraP2P_1_1preambleLength.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#gae1d27f0bc8dfb970f6caec636ad3730c", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga9acd28f0b3cedc10ca55e404a70b3a42", null ]
    ] ],
    [ "codingrate", "df/d67/classRAKLoraP2P_1_1codingrate.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7078407bba64d8341d38f517836858f1", null ]
    ] ],
    [ "speradingFactor", "df/dcd/classRAKLoraP2P_1_1speradingFactor.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga67f3e32e8dee8c91ea7d8c3edfd4c828", null ]
    ] ],
    [ "bandwidth", "dd/dc0/classRAKLoraP2P_1_1bandwidth.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gae837384d7164d542f3bf871a8155fadc", null ]
    ] ],
    [ "txOutputPower", "d7/da2/classRAKLoraP2P_1_1txOutputPower.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaba3a03ff0742e917d9b79aaf70e55907", null ]
    ] ],
    [ "rfFrequency", "d6/dcf/classRAKLoraP2P_1_1rfFrequency.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gacd34fd452f595ba9c5db4cea370c474a", null ]
    ] ],
    [ "syncword", "d4/d12/classRAKLoraP2P_1_1syncword.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaa785129535a31eb87792edc5eebe38c7", null ]
    ] ],
    [ "iqInver", "d3/d49/classRAKLoraP2P_1_1iqInver.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7e43fc01bd6ae68ce2723c708c47e47d", null ]
    ] ],
    [ "RAK_LORA_McSession", "df/d1f/structRAK__LORA__McSession.html", [
      [ "McDevclass", "df/d1f/structRAK__LORA__McSession.html#a8880c6395ab3e45bfdb3ff4153764e3e", null ],
      [ "McAddress", "df/d1f/structRAK__LORA__McSession.html#a91d59aabc7b3cf1524cff9dfa3ff0f4f", null ],
      [ "McAppSKey", "df/d1f/structRAK__LORA__McSession.html#a3e5410de49004f5bf990b10e4902e00f", null ],
      [ "McNwkSKey", "df/d1f/structRAK__LORA__McSession.html#a3e42e3e105838ca7d1cf6cadbab6ac0b", null ],
      [ "McFrequency", "df/d1f/structRAK__LORA__McSession.html#a5df76ee656aad7c54e40fbd9d572d285", null ],
      [ "McDatarate", "df/d1f/structRAK__LORA__McSession.html#a76c6c14c005e0155001047886ff5d14a", null ],
      [ "McPeriodicity", "df/d1f/structRAK__LORA__McSession.html#aee13d3d2aba615042dd92bd1f43cde37", null ],
      [ "McGroupID", "df/d1f/structRAK__LORA__McSession.html#a1fbcc23862f1d55f67519f6ad7a8cbb7", null ],
      [ "entry", "df/d1f/structRAK__LORA__McSession.html#adbdb38b7f14c384804844026547a276e", null ]
    ] ],
    [ "RAK_LORA_chan_rssi", "d1/d81/structRAK__LORA__chan__rssi.html", [
      [ "chan", "d1/d81/structRAK__LORA__chan__rssi.html#afb67f3e4e204785118073a96b76614d6", null ],
      [ "mask", "d1/d81/structRAK__LORA__chan__rssi.html#a7fd850d4bb04f7410e8e2abf5f349348", null ],
      [ "rssi", "d1/d81/structRAK__LORA__chan__rssi.html#a3b962e67ba74725bd60ca3c29f785abe", null ]
    ] ],
    [ "RAK_LORA_BAND", "de/d56/group__RUI__Lorawan__Data__Type.html#ga4b8c367e751e52fdb9bf0daeb01f501b", [
      [ "RAK_REGION_EU433", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba1fbeaac26403fc93d4ca51dbae407a72", null ],
      [ "RAK_REGION_CN470", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba62d066d2c1686b8df226cd43adec850f", null ],
      [ "RAK_REGION_RU864", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba193a6f81065ed5059d31966f717625d6", null ],
      [ "RAK_REGION_IN865", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501baa55ac5d51e0d00d86d4ad6f35d72534f", null ],
      [ "RAK_REGION_EU868", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501baf251060a5ebbd49acdfa9ee459c6ab16", null ],
      [ "RAK_REGION_US915", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501baf51e8c3353b5773cd81ffa31ca8de950", null ],
      [ "RAK_REGION_AU915", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba9d01575b3d4697a4ba78f9f13d04824e", null ],
      [ "RAK_REGION_KR920", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501bac221eb115d632600c809ea947d5d24eb", null ],
      [ "RAK_REGION_AS923", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba09f40ae957af953e8a57002d9e6acbb6", null ],
      [ "RAK_REGION_AS923_2", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba240eceec7e7ca12ae5519c4bab1eb195", null ],
      [ "RAK_REGION_AS923_3", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba0941ee7356d71245ae712bd22b095c83", null ],
      [ "RAK_REGION_AS923_4", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba42a4150d94f2cf9ec62ca7432f07b36a", null ]
    ] ],
    [ "RAK_LORA_JOIN_MODE", "de/d56/group__RUI__Lorawan__Data__Type.html#gae0315aed26d67c63ae036a2b8f6a58ab", [
      [ "RAK_LORA_ABP", "de/d56/group__RUI__Lorawan__Data__Type.html#ggae0315aed26d67c63ae036a2b8f6a58abac955cb4a6f6e20996e3335f33ab6e88a", null ],
      [ "RAK_LORA_OTAA", "de/d56/group__RUI__Lorawan__Data__Type.html#ggae0315aed26d67c63ae036a2b8f6a58aba561f1f24597f9b4b58c887b7594dc6ea", null ]
    ] ],
    [ "RAK_LORA_WORK_MODE", "de/d56/group__RUI__Lorawan__Data__Type.html#ga690c7d508c5a6bed2e3bdc49f787bd04", [
      [ "RAK_LORA_P2P", "de/d56/group__RUI__Lorawan__Data__Type.html#gga690c7d508c5a6bed2e3bdc49f787bd04a70fc57bba1fc9021716021162d90ed02", null ],
      [ "RAK_LORAWAN", "de/d56/group__RUI__Lorawan__Data__Type.html#gga690c7d508c5a6bed2e3bdc49f787bd04a32926a4738102f4b006ebe40b70e7658", null ],
      [ "RAK_LORA_FSK", "de/d56/group__RUI__Lorawan__Data__Type.html#gga690c7d508c5a6bed2e3bdc49f787bd04a9c9a1e4c61c6c310df767fb3a75ae1e3", null ]
    ] ],
    [ "RAK_LORA_CONFIRM_MODE", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8fde2d1fa94b843144063b2f56260d2d", [
      [ "RAK_LORA_NO_ACK", "de/d56/group__RUI__Lorawan__Data__Type.html#gga8fde2d1fa94b843144063b2f56260d2da67023bb91de2fe123df48ef47b71ae2c", null ],
      [ "RAK_LORA_ACK", "de/d56/group__RUI__Lorawan__Data__Type.html#gga8fde2d1fa94b843144063b2f56260d2dae26518a000ed7ae5371a190691b014f1", null ]
    ] ],
    [ "RAK_LORA_CLASS", "de/d56/group__RUI__Lorawan__Data__Type.html#gab23a5817dcc95b55ac49f9ed52b660fe", [
      [ "RAK_LORA_CLASS_A", "de/d56/group__RUI__Lorawan__Data__Type.html#ggab23a5817dcc95b55ac49f9ed52b660fea65004a128fd53f1742be4fcf6a7cf1df", null ],
      [ "RAK_LORA_CLASS_B", "de/d56/group__RUI__Lorawan__Data__Type.html#ggab23a5817dcc95b55ac49f9ed52b660fea701e64d10dd68f6dc8636bd2164fe2b2", null ],
      [ "RAK_LORA_CLASS_C", "de/d56/group__RUI__Lorawan__Data__Type.html#ggab23a5817dcc95b55ac49f9ed52b660fea20757f4cfcb9c4b21465301bc30032ac", null ]
    ] ],
    [ "RAKLoraP2P", "de/d56/group__RUI__Lorawan__Data__Type.html#ga16017aceba9b637180e264c4e410c802", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7e43fc01bd6ae68ce2723c708c47e47d", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaa785129535a31eb87792edc5eebe38c7", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gacd34fd452f595ba9c5db4cea370c474a", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaba3a03ff0742e917d9b79aaf70e55907", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gae837384d7164d542f3bf871a8155fadc", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga67f3e32e8dee8c91ea7d8c3edfd4c828", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7078407bba64d8341d38f517836858f1", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#gae1d27f0bc8dfb970f6caec636ad3730c", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga9acd28f0b3cedc10ca55e404a70b3a42", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaf27fd3bf5132a7da2c6d48d11605beee", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5a0ac596ad458f81229cb3b8542c99a7", null ],
    [ "iqInver", "de/d56/group__RUI__Lorawan__Data__Type.html#gadbe5448b21c73b7771f0f63bb657053b", null ],
    [ "syncword", "de/d56/group__RUI__Lorawan__Data__Type.html#ga652a2465541aa497f68e1e4281890073", null ],
    [ "rfFrequency", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7bd30bc7a5f4ba3fe21d34a2828caaa0", null ],
    [ "txOutputPower", "de/d56/group__RUI__Lorawan__Data__Type.html#ga1e27bec3900515642d8d8e5758af484e", null ],
    [ "bandwidth", "de/d56/group__RUI__Lorawan__Data__Type.html#gafd12eaaa8c52eb3fc5343aac8ee957e7", null ],
    [ "speradingFactor", "de/d56/group__RUI__Lorawan__Data__Type.html#gae4020faa1144f6df1b792462cd64b783", null ],
    [ "codingrate", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7dc745794c81f0e6cd15bb98449b71c5", null ],
    [ "preambleLength", "de/d56/group__RUI__Lorawan__Data__Type.html#ga3c3e21b522152e8f90c588fbb2b78667", null ],
    [ "symbolTimeout", "de/d56/group__RUI__Lorawan__Data__Type.html#ga903790f622e90e8754dc6d9391666f51", null ],
    [ "fixLengthPayload", "de/d56/group__RUI__Lorawan__Data__Type.html#gad4e43af408e69c81bb81b66c758f3269", null ]
];