var group__RUI__Arduino__Data__Type =
[
    [ "eAnalogReference", "da/dc1/group__RUI__Arduino__Data__Type.html#ga94a0a084b94d647b5f2acbc709af247e", null ],
    [ "RAK_SERIAL_MODE", "da/dc1/group__RUI__Arduino__Data__Type.html#ga16a0db3626fcdcf41532df39cc7ab989", [
      [ "RAK_AT_MODE", "da/dc1/group__RUI__Arduino__Data__Type.html#gga16a0db3626fcdcf41532df39cc7ab989ac2257f579d76554fbd5aeaca733d4030", null ],
      [ "RAK_API_MODE", "da/dc1/group__RUI__Arduino__Data__Type.html#gga16a0db3626fcdcf41532df39cc7ab989ab2462b064dabe95f52abe4577deae213", null ],
      [ "RAK_CUSTOM_MODE", "da/dc1/group__RUI__Arduino__Data__Type.html#gga16a0db3626fcdcf41532df39cc7ab989a330b877e9e366c0504128567a4115f8e", null ],
      [ "RAK_DEFAULT_MODE", "da/dc1/group__RUI__Arduino__Data__Type.html#gga16a0db3626fcdcf41532df39cc7ab989ab7ad335ddda6ef87d73d0564ab820f97", null ]
    ] ],
    [ "RAK_ADC_RESOLUTION", "da/dc1/group__RUI__Arduino__Data__Type.html#gab9780fbfa8e1586d992b12efeb7721d1", [
      [ "RAK_ADC_RESOLUTION_8BIT", "da/dc1/group__RUI__Arduino__Data__Type.html#ggab9780fbfa8e1586d992b12efeb7721d1a4dadeca9c742154ae826bb9fb1fcad38", null ],
      [ "RAK_ADC_RESOLUTION_10BIT", "da/dc1/group__RUI__Arduino__Data__Type.html#ggab9780fbfa8e1586d992b12efeb7721d1a313540a000f4f38f15578b0d3d1e2356", null ],
      [ "RAK_ADC_RESOLUTION_12BIT", "da/dc1/group__RUI__Arduino__Data__Type.html#ggab9780fbfa8e1586d992b12efeb7721d1a419c0d347b3062b06897cb651fd4c437", null ],
      [ "RAK_ADC_RESOLUTION_14BIT", "da/dc1/group__RUI__Arduino__Data__Type.html#ggab9780fbfa8e1586d992b12efeb7721d1a4faf585311797da5f421011e062fa739", null ]
    ] ],
    [ "RAK_ADC_MODE", "da/dc1/group__RUI__Arduino__Data__Type.html#ga120712ef7fadb870d500c2ff354b7dff", [
      [ "RAK_ADC_MODE_DEFAULT", "da/dc1/group__RUI__Arduino__Data__Type.html#gga120712ef7fadb870d500c2ff354b7dffa4a8fe86e4f8954e32a6b055f1d677cd5", null ],
      [ "RAK_ADC_MODE_3_0", "da/dc1/group__RUI__Arduino__Data__Type.html#gga120712ef7fadb870d500c2ff354b7dffaa3d7fa338d7112c7ba6d3bf0b1be2df9", null ],
      [ "RAK_ADC_MODE_2_4", "da/dc1/group__RUI__Arduino__Data__Type.html#gga120712ef7fadb870d500c2ff354b7dffa58b34f2785987622d34cedacd93cdde1", null ],
      [ "RAK_ADC_MODE_1_8", "da/dc1/group__RUI__Arduino__Data__Type.html#gga120712ef7fadb870d500c2ff354b7dffa6bd225e4e5f513429e65c9f1562aaff8", null ],
      [ "RAK_ADC_MODE_1_2", "da/dc1/group__RUI__Arduino__Data__Type.html#gga120712ef7fadb870d500c2ff354b7dffa2298db25cb5b81d0ea749088e0df634d", null ]
    ] ],
    [ "RAK_PWM_RESOLUTION", "da/dc1/group__RUI__Arduino__Data__Type.html#ga3dbd786e9f26032195c87a4a298edaa2", [
      [ "RAK_PWM_RESOLUTION_8BIT", "da/dc1/group__RUI__Arduino__Data__Type.html#gga3dbd786e9f26032195c87a4a298edaa2a2ed52c99e43cc7ad9e2f74f745ef76c4", null ],
      [ "RAK_PWM_RESOLUTION_10BIT", "da/dc1/group__RUI__Arduino__Data__Type.html#gga3dbd786e9f26032195c87a4a298edaa2afb63ee86c4012e4da073d36500d33268", null ],
      [ "RAK_PWM_RESOLUTION_12BIT", "da/dc1/group__RUI__Arduino__Data__Type.html#gga3dbd786e9f26032195c87a4a298edaa2ad9b954d7c776fd4999a51792604bb8e4", null ],
      [ "RAK_PWM_RESOLUTION_14BIT", "da/dc1/group__RUI__Arduino__Data__Type.html#gga3dbd786e9f26032195c87a4a298edaa2aeeac83b1de50d0d58442cb28213db19b", null ]
    ] ],
    [ "_eAnalogReference", "da/dc1/group__RUI__Arduino__Data__Type.html#gacc921e9f1c5c0306cfc61a046a99c3cc", [
      [ "AR_DEFAULT", "da/dc1/group__RUI__Arduino__Data__Type.html#ggacc921e9f1c5c0306cfc61a046a99c3cca2036ddc9b1f223ef67174dbbfd13c918", null ],
      [ "AR_INTERNAL", "da/dc1/group__RUI__Arduino__Data__Type.html#ggacc921e9f1c5c0306cfc61a046a99c3cca87a6a42ff3aa3adb562cbd821ebae568", null ],
      [ "AR_INTERNAL_3_0", "da/dc1/group__RUI__Arduino__Data__Type.html#ggacc921e9f1c5c0306cfc61a046a99c3cca3970f1e49f4c84e4574cb24426c70c21", null ],
      [ "AR_INTERNAL_2_4", "da/dc1/group__RUI__Arduino__Data__Type.html#ggacc921e9f1c5c0306cfc61a046a99c3cca439d80903d0e7606d2006ac03fdb1553", null ],
      [ "AR_INTERNAL_1_8", "da/dc1/group__RUI__Arduino__Data__Type.html#ggacc921e9f1c5c0306cfc61a046a99c3cca99d6dcd5a2f8d7b708c0193823092411", null ],
      [ "AR_INTERNAL_1_2", "da/dc1/group__RUI__Arduino__Data__Type.html#ggacc921e9f1c5c0306cfc61a046a99c3cca523fa89fc45c097472a34c0387c27bac", null ]
    ] ]
];