var group__OPT3001 =
[
    [ "init", "d0/d4a/group__OPT3001.html#ga988e7824fd6ad20a5ad876f9438cded8", null ],
    [ "update", "d0/d4a/group__OPT3001.html#ga9438cac90044de6fb9d4d93d27df32bd", null ],
    [ "lux", "d0/d4a/group__OPT3001.html#gaf7ce5e542c6e2be8a839230d6cf8caf8", null ]
];