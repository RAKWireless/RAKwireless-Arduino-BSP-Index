var group__I__Beacon =
[
    [ "uuid", "db/d1b/group__Beacon__UUID.html", "db/d1b/group__Beacon__UUID" ],
    [ "major", "d2/d31/group__Beacon__Major.html", "d2/d31/group__Beacon__Major" ],
    [ "minor", "d3/d76/group__Beacon__Minor.html", "d3/d76/group__Beacon__Minor" ],
    [ "power", "d5/db1/group__Beacon__Power.html", "d5/db1/group__Beacon__Power" ],
    [ "set", "dd/d4f/group__I__Beacon.html#gab9eaa6ae2252218707b2928166c1821c", null ]
];