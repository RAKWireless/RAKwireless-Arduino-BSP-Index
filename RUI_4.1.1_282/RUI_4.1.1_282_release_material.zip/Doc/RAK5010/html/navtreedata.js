var NAVTREE =
[
  [ "RUI3 (RAK Unified Interface 3)  - RAK5010", "index.html", [
    [ "AT Command Manual", "df/db6/ATCMD.html", [
      [ "Bootloader Command", "df/db6/ATCMD.html#ATCMD_bootloader", [
        [ "AT+VER: Version of the Bootloader (bootloader only)", "df/db6/ATCMD.html#ATCMD_bootloader_1", null ],
        [ "AT+VERSION: Version of the Bootloader (bootloader only)", "df/db6/ATCMD.html#ATCMD_bootloader_2", null ],
        [ "AT+BOOTSTATUS: the status of the bootloader (bootloader only)", "df/db6/ATCMD.html#ATCMD_bootloader_3", null ],
        [ "AT+RUN: leaving boot mode (bootloader only)", "df/db6/ATCMD.html#ATCMD_bootloader_4", null ],
        [ "AT+RESET: device reset (bootloader only)", "df/db6/ATCMD.html#ATCMD_bootloader_5", null ]
      ] ],
      [ "Cellular Command", "df/db6/ATCMD.html#ATCMD_cellular", [
        [ "AT+CELL: Send cellular commnad", "df/db6/ATCMD.html#ATCMD_cellular_1", null ]
      ] ],
      [ "General Command", "df/db6/ATCMD.html#ATCMD_general", [
        [ "AT: Attention", "df/db6/ATCMD.html#ATCMD_general_1", null ],
        [ "AT?: Short Help", "df/db6/ATCMD.html#ATCMD_general_2", null ],
        [ "ATZ: MCU Reset", "df/db6/ATCMD.html#ATCMD_general_3", null ],
        [ "ATR: Restore Default Parameters", "df/db6/ATCMD.html#ATCMD_general_4", null ],
        [ "AT+BOOT: Bootloader Mode", "df/db6/ATCMD.html#ATCMD_general_5", null ],
        [ "ATE: Command Echo", "df/db6/ATCMD.html#ATCMD_general_6", null ],
        [ "AT+SN: get the serial number of the device", "df/db6/ATCMD.html#ATCMD_general_7", null ],
        [ "AT+BAT: Battery Level", "df/db6/ATCMD.html#ATCMD_general_8", null ],
        [ "AT+BUILDTIME: Build Time of the Firmware", "df/db6/ATCMD.html#ATCMD_general_9", null ],
        [ "AT+REPOINFO: Repository Information", "df/db6/ATCMD.html#ATCMD_general_10", null ],
        [ "AT+VER: Version of the Firmware", "df/db6/ATCMD.html#ATCMD_general_11", null ],
        [ "AT+CLIVER: Version of the AT Command", "df/db6/ATCMD.html#ATCMD_general_12", null ],
        [ "AT+APIVER: Version of the RUI API", "df/db6/ATCMD.html#ATCMD_general_13", null ],
        [ "AT+HWMODEL: Hardware Model", "df/db6/ATCMD.html#ATCMD_general_14", null ],
        [ "AT+HWID: Hardware ID", "df/db6/ATCMD.html#ATCMD_general_15", null ],
        [ "AT+ALIAS: Alias Name of the Device", "df/db6/ATCMD.html#ATCMD_general_16", null ],
        [ "AT+SYSV: get the System Voltage", "df/db6/ATCMD.html#ATCMD_general_17", null ],
        [ "AT+BLEMAC: get or set the BLE Mac address", "df/db6/ATCMD.html#ATCMD_general_18", null ],
        [ "AT+BOOTVER: get the version of RUI Bootloader", "df/db6/ATCMD.html#ATCMD_general_19", null ]
      ] ],
      [ "Serial Port Command", "df/db6/ATCMD.html#ATCMD_serial_port", [
        [ "AT+LOCK: Lock the AT command serial port", "df/db6/ATCMD.html#ATCMD_serial_port_1", null ],
        [ "AT+PWORD: the password for locking the AT command serial port", "df/db6/ATCMD.html#ATCMD_serial_port_2", null ],
        [ "AT+BAUD: the serial port baudrate", "df/db6/ATCMD.html#ATCMD_serial_port_3", null ],
        [ "AT+ATM: AT command mode", "df/db6/ATCMD.html#ATCMD_serial_port_4", null ],
        [ "AT+APM: API mode", "df/db6/ATCMD.html#ATCMD_serial_port_5", null ]
      ] ],
      [ "Sleep Command", "df/db6/ATCMD.html#ATCMD_sleep", [
        [ "AT+SLEEP: sleep mode", "df/db6/ATCMD.html#ATCMD_sleep_1", null ],
        [ "AT+LPM: low power mode", "df/db6/ATCMD.html#ATCMD_sleep_2", null ],
        [ "AT+LPMLVL: the sleep level for low power mode", "df/db6/ATCMD.html#ATCMD_sleep_3", null ]
      ] ]
    ] ],
    [ "RUI3 API", "modules.html", "modules" ]
  ] ]
];

var NAVTREEINDEX =
[
"d0/d00/classlpm.html",
"dc/dc6/group__Serial.html#ga6ee174e74a6d460c4327c42f74ddc62b"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';