var group__BLE__MAC =
[
    [ "get", "da/ded/group__BLE__MAC.html#ga2f97a3838484bbb987f4dd9df522d6b5", null ],
    [ "set", "da/ded/group__BLE__MAC.html#gaed21959cdab85952e690de54c706e8e2", null ]
];