var group__SHTC3 =
[
    [ "init", "d9/d43/group__SHTC3.html#ga988e7824fd6ad20a5ad876f9438cded8", null ],
    [ "wakeup", "d9/d43/group__SHTC3.html#ga0222c1c1ee03b17bc0aab50160e0cfa6", null ],
    [ "sleep", "d9/d43/group__SHTC3.html#ga733b7bf0743a4aa404ce0c99acf1d9b0", null ],
    [ "update", "d9/d43/group__SHTC3.html#ga9438cac90044de6fb9d4d93d27df32bd", null ],
    [ "temperature", "d9/d43/group__SHTC3.html#ga87a4e3b50387e258ee1b341f4b78bcc1", null ],
    [ "humidity", "d9/d43/group__SHTC3.html#gaee3cb459114dd562c921819fb0ce01d4", null ]
];