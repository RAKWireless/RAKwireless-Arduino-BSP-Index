var searchData=
[
  ['binary_2eh_0',['binary.h',['../d8/da4/binary_8h.html',1,'']]]
];
