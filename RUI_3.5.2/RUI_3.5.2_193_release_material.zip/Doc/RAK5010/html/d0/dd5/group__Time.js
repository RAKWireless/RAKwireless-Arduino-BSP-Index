var group__Time =
[
    [ "delay", "d0/dd5/group__Time.html#gac16a222c648fdce7e5eb4f7e6cdb4d9d", null ],
    [ "delayMicroseconds", "d0/dd5/group__Time.html#ga0e27e8ce66e8f4a2c9609d80aac301f7", null ],
    [ "millis", "d0/dd5/group__Time.html#ga6ff7f2532a22366f0013bc41397129fd", null ],
    [ "micros", "d0/dd5/group__Time.html#ga8b24cbb7c3486e1bfa05c86db83ecb01", null ]
];