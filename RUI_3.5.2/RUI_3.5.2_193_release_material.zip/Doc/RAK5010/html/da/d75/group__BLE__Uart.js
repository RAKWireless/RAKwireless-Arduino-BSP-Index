var group__BLE__Uart =
[
    [ "start", "da/d75/group__BLE__Uart.html#gaedc96a40e844bc2efc8bbef1b0782702", null ],
    [ "stop", "da/d75/group__BLE__Uart.html#gaacf6bf8e121fea8b0a92d7197b73fe27", null ],
    [ "available", "da/d75/group__BLE__Uart.html#ga2b8f8d4e0030145608f5884a1e118b2e", null ],
    [ "read", "da/d75/group__BLE__Uart.html#ga5a11f1618a458b2372ad263f0e6d883a", null ],
    [ "write", "da/d75/group__BLE__Uart.html#gaa72a1a6dca179fdb87ca693c456226c7", null ],
    [ "setPIN", "da/d75/group__BLE__Uart.html#ga5c91a7e2adbc7d4b6a2a7533d5696501", null ],
    [ "setPermission", "da/d75/group__BLE__Uart.html#ga2d31323b5e2355ebeb1494a8a4b6d59b", null ]
];