var group__System__Battery =
[
    [ "get", "d2/ddb/group__System__Battery.html#gaaeead681ea04e968a911de965946ee81", null ]
];