var group__Device__Information =
[
    [ "Firmware Version", "d5/dcd/group__Firmware__Version.html", "d5/dcd/group__Firmware__Version" ],
    [ "Cli Version", "d0/df4/group__Cli__Version.html", "d0/df4/group__Cli__Version" ],
    [ "Api Version", "d0/dc9/group__Api__Version.html", "d0/dc9/group__Api__Version" ],
    [ "Model ID", "de/d68/group__Model__ID.html", "de/d68/group__Model__ID" ],
    [ "Chip ID", "d7/da1/group__Chip__ID.html", "d7/da1/group__Chip__ID" ],
    [ "Battery", "d2/ddb/group__System__Battery.html", "d2/ddb/group__System__Battery" ]
];