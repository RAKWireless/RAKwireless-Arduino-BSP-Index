var group__System =
[
    [ "RUI System Data Type", "d4/df2/group__RUI__System__Data__Type.html", "d4/df2/group__RUI__System__Data__Type" ],
    [ "Device Information", "dc/d49/group__Device__Information.html", "dc/d49/group__Device__Information" ],
    [ "Flash", "d7/d2f/group__Flash.html", "d7/d2f/group__Flash" ],
    [ "Powersave", "d8/dc1/group__Powersave.html", "d8/dc1/group__Powersave" ],
    [ "timer", "df/dd3/group__System__Timer.html", "df/dd3/group__System__Timer" ],
    [ "scheduler", "dd/dc4/group__System__Scheduler.html", "dd/dc4/group__System__Scheduler" ],
    [ "Misc", "de/de4/group__System__Misc.html", "de/de4/group__System__Misc" ]
];