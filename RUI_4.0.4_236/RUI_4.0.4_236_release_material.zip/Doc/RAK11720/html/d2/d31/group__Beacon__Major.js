var group__Beacon__Major =
[
    [ "set", "d2/d31/group__Beacon__Major.html#ga99470a73f7e6e52e9e7ad1a79be3ea92", null ]
];