var searchData=
[
  ['uuid',['uuid',['../db/d1b/group__Beacon__UUID.html',1,'']]]
];
