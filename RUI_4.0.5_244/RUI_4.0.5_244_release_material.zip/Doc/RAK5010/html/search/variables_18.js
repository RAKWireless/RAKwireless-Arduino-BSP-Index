var searchData=
[
  ['yaccelenabled',['yAccelEnabled',['../df/dde/structrak1904Setting.html#a28685b2bac636c94febe8045222ff859',1,'rak1904Setting']]],
  ['year',['year',['../dc/d7f/structdate__time__s.html#a57ca98d8f6d4baf0fe41c583c7dcb0d5',1,'date_time_s']]]
];
