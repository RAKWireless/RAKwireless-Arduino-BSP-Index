var searchData=
[
  ['hardwareserial',['HardwareSerial',['../dd/d56/classHardwareSerial.html#aa273284cb8d9e40841e0bc482c4d4d2c',1,'HardwareSerial']]],
  ['hdop',['hdop',['../d2/d48/classrak1910.html#aad971d344e39679867b7933702b18789',1,'rak1910::hdop()'],['../d3/d41/structTinyGPSHDOP.html#a503ec1ef74b59266b4c8b5c19826370c',1,'TinyGPSHDOP::hdop()']]],
  ['hour',['hour',['../db/de3/structTinyGPSTime.html#a4a05b3dd41da0735768ea22dded75e82',1,'TinyGPSTime']]],
  ['humidity',['humidity',['../d9/d43/group__SHTC3.html#gaee3cb459114dd562c921819fb0ce01d4',1,'rak1901::humidity()'],['../de/dc5/classrak1906.html#aee3cb459114dd562c921819fb0ce01d4',1,'rak1906::humidity()']]]
];
