var group__Supplement =
[
    [ "RAKLorawan::mask", "dd/d67/classRAKLorawan_1_1mask.html", [
      [ "get", "dd/d67/classRAKLorawan_1_1mask.html#a8a73999d7c2b0f91287309798b71c0ad", null ],
      [ "set", "dd/d67/classRAKLorawan_1_1mask.html#ae20a000946b23fb3cd2f155ad5f1f3cc", null ]
    ] ],
    [ "RAKLorawan::band", "d3/d33/classRAKLorawan_1_1band.html", [
      [ "get", "d3/d33/classRAKLorawan_1_1band.html#a778335fa79020bb947b8730d3cd6fa4b", null ],
      [ "set", "d3/d33/classRAKLorawan_1_1band.html#ac3bbc06f12ee4803c554efae5bc32d0b", null ]
    ] ]
];