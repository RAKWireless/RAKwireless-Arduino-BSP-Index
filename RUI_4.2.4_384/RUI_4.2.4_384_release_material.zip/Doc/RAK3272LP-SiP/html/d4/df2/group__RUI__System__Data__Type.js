var group__RUI__System__Data__Type =
[
    [ "RAK_EXTFLASH_INFO", "d8/d79/structRAK__EXTFLASH__INFO.html", [
      [ "total_size", "d8/d79/structRAK__EXTFLASH__INFO.html#acdfd526bb392e1ee59a3c6c545891b48", null ],
      [ "sector_size", "d8/d79/structRAK__EXTFLASH__INFO.html#a7d37def484362c6e97a2d75144080b1d", null ],
      [ "page_size", "d8/d79/structRAK__EXTFLASH__INFO.html#a9dd3e47e968a8f6beb5d88c6d1b7ebe9", null ],
      [ "jedec_id", "d8/d79/structRAK__EXTFLASH__INFO.html#a8ce1bcf825bb788762d1b8bec858140e", null ]
    ] ],
    [ "RAK_TIMER_HANDLER", "d4/df2/group__RUI__System__Data__Type.html#ga8d174c78ce32ce25e92b8f24bc716190", null ],
    [ "RAK_TASK_HANDLER", "d4/df2/group__RUI__System__Data__Type.html#gadfc501bb9dbed63277841c8ccb42c23a", null ],
    [ "RAK_AT_PERMISSION", "d4/df2/group__RUI__System__Data__Type.html#ga79e514044e3507de705f7a3daff70362", [
      [ "RAK_ATCMD_PERM_WRITE", "d4/df2/group__RUI__System__Data__Type.html#gga79e514044e3507de705f7a3daff70362ab2f7b261a3ed23ee588d032f6546dc29", null ],
      [ "RAK_ATCMD_PERM_READ", "d4/df2/group__RUI__System__Data__Type.html#gga79e514044e3507de705f7a3daff70362ac3c519eddb9d27b6a606edcb78037980", null ],
      [ "RAK_ATCMD_PERM_WRITEONCEREAD", "d4/df2/group__RUI__System__Data__Type.html#gga79e514044e3507de705f7a3daff70362ad6559cd712bb9b985015985bedc242cd", null ],
      [ "RAK_ATCMD_PERM_DISABLE", "d4/df2/group__RUI__System__Data__Type.html#gga79e514044e3507de705f7a3daff70362ae6ab627f9f849530259b1b16e70e0d53", null ]
    ] ],
    [ "RAK_TIMER_ID", "d4/df2/group__RUI__System__Data__Type.html#gab5d18f2ead2c1930487bbaebb9c96992", [
      [ "RAK_TIMER_0", "d4/df2/group__RUI__System__Data__Type.html#ggab5d18f2ead2c1930487bbaebb9c96992a415152523b795963b813a7f907701118", null ],
      [ "RAK_TIMER_1", "d4/df2/group__RUI__System__Data__Type.html#ggab5d18f2ead2c1930487bbaebb9c96992adc3ab9a84e90e49736e6d399cfba6bc0", null ],
      [ "RAK_TIMER_2", "d4/df2/group__RUI__System__Data__Type.html#ggab5d18f2ead2c1930487bbaebb9c96992a599b816590f72ec4eb2f8d838c21b3b1", null ],
      [ "RAK_TIMER_3", "d4/df2/group__RUI__System__Data__Type.html#ggab5d18f2ead2c1930487bbaebb9c96992acec18373d3e1f016fb8756b568404967", null ],
      [ "RAK_TIMER_4", "d4/df2/group__RUI__System__Data__Type.html#ggab5d18f2ead2c1930487bbaebb9c96992a7e3a1e701e59cc2dcc62f58f44a63a2a", null ],
      [ "RAK_TIMER_ID_MAX", "d4/df2/group__RUI__System__Data__Type.html#ggab5d18f2ead2c1930487bbaebb9c96992afd65f30d21b5ce96d8f67694611a0c84", null ]
    ] ],
    [ "RAK_TIMER_MODE", "d4/df2/group__RUI__System__Data__Type.html#ga2a231b1ecf3e2d10794e135417dd70b3", [
      [ "RAK_TIMER_ONESHOT", "d4/df2/group__RUI__System__Data__Type.html#gga2a231b1ecf3e2d10794e135417dd70b3a6b931ff0cca8f047c7ab8f6adf1b1832", null ],
      [ "RAK_TIMER_PERIODIC", "d4/df2/group__RUI__System__Data__Type.html#gga2a231b1ecf3e2d10794e135417dd70b3ae93e380d185715004ea683a09956cfa5", null ]
    ] ],
    [ "RUI_WAKEUP_TRIGGER_MODE", "d4/df2/group__RUI__System__Data__Type.html#ga31fe1577eaa016ae1573cd1e5223284e", [
      [ "RUI_WAKEUP_RISING_EDGE", "d4/df2/group__RUI__System__Data__Type.html#gga31fe1577eaa016ae1573cd1e5223284ea07b149cf9f354e1cf6c654fa056993d0", null ],
      [ "RUI_WAKEUP_FALLING_EDGE", "d4/df2/group__RUI__System__Data__Type.html#gga31fe1577eaa016ae1573cd1e5223284ea2754141bd5d4fa1cb75c50d5555cab3b", null ]
    ] ]
];