var group__AdvancedIO =
[
    [ "tone", "da/daf/group__AdvancedIO.html#gaa2af98ff63e517d9adae85853eb32165", null ],
    [ "noTone", "da/daf/group__AdvancedIO.html#ga6bded078d2eabd545f6afec198154207", null ],
    [ "shiftOut", "da/daf/group__AdvancedIO.html#gac44afc7b9d1ec5feb1179b2e3454690a", null ],
    [ "shiftIn", "da/daf/group__AdvancedIO.html#gaf45599d02105757205eeec9b8de81a7a", null ],
    [ "pulseIn", "da/daf/group__AdvancedIO.html#ga5325dc5cc7eb72ca7ea964f9bd7a0362", null ],
    [ "pulseInLong", "da/daf/group__AdvancedIO.html#ga0980ea6c76f820bc64b7f25466cdcb1e", null ]
];