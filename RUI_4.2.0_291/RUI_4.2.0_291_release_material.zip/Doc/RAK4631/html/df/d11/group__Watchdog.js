var group__Watchdog =
[
    [ "enable", "df/d11/group__Watchdog.html#gafed997b13ff2bcdbd26ccd1b0a97eae1", null ],
    [ "reset", "df/d11/group__Watchdog.html#ga3aea9deb2a0bfea9ff05a898f4822e31", null ]
];