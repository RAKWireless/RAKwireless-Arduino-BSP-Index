var searchData=
[
  ['udrv_5fadc_5fmode',['UDRV_ADC_MODE',['../d9/d25/udrv__adc_8h.html#a726dd87e8167bf284b796489e60b220c',1,'udrv_adc.h']]],
  ['udrv_5fadc_5fresolution',['UDRV_ADC_RESOLUTION',['../d9/d25/udrv__adc_8h.html#ac77e72d62d2cb4f108a48adb98010fe2',1,'udrv_adc.h']]],
  ['udrv_5fnfc_5ft4t_5fevent',['UDRV_NFC_T4T_EVENT',['../d5/d62/udrv__nfc_8h.html#a70d3151012f11687266770854fed37a5',1,'udrv_nfc.h']]],
  ['udrv_5fnfc_5furi_5fid',['UDRV_NFC_URI_ID',['../d5/d62/udrv__nfc_8h.html#ac52653291020eaba9ab5883287c00992',1,'udrv_nfc.h']]],
  ['udrv_5fpdm_5fevent_5ft',['udrv_pdm_event_t',['../d7/d26/udrv__pdm_8h.html#a79e091dda6cc8528496616b29fd317f6',1,'udrv_pdm.h']]],
  ['udrv_5fpdm_5ftask_5ft',['udrv_pdm_task_t',['../d7/d26/udrv__pdm_8h.html#a847a58ef1754a5a0c183336acc659b9f',1,'udrv_pdm.h']]],
  ['udrv_5fpwm_5fport',['udrv_pwm_port',['../d2/db3/udrv__pwm_8h.html#a13d33ee3ec3724479bf9eacfcf0e5c2b',1,'udrv_pwm.h']]],
  ['udrv_5fpwm_5fresolution',['UDRV_PWM_RESOLUTION',['../d2/db3/udrv__pwm_8h.html#a7f967aa119280b6674436779b00aaba3',1,'udrv_pwm.h']]],
  ['udrv_5fspimst_5fport',['udrv_spimst_port',['../d2/df3/udrv__spimst_8h.html#a889d6c8b350700443b39debe8d44c396',1,'udrv_spimst.h']]],
  ['udrv_5fsystem_5fevent_5fop_5ft',['udrv_system_event_op_t',['../d7/d4a/udrv__system_8h.html#a4aabc69bc292fb5236e114ebef0e7d7b',1,'udrv_system.h']]],
  ['udrv_5ftwimst_5fport',['udrv_twimst_port',['../da/de0/udrv__twimst_8h.html#a982901c506e2770f74a1b72c14663418',1,'udrv_twimst.h']]]
];
