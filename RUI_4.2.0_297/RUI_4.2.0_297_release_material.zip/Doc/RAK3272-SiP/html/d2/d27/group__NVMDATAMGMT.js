var group__NVMDATAMGMT =
[
    [ "NvmDataMgmtEvent", "d2/d27/group__NVMDATAMGMT.html#ga3a13c591f7153b8723f26f55508597e8", null ],
    [ "NvmDataMgmtStore", "d2/d27/group__NVMDATAMGMT.html#ga1d414359cfd6a3e048fd92ebf0c04b82", null ],
    [ "NvmDataMgmtRestore", "d2/d27/group__NVMDATAMGMT.html#ga65af07bbcdef3be4b31feaaf61222786", null ],
    [ "NvmDataMgmtFactoryReset", "d2/d27/group__NVMDATAMGMT.html#ga00ce203b4fbf25ee7511b0cb663c5688", null ]
];