var group__BLE__Scanner =
[
    [ "start", "d5/d6f/group__BLE__Scanner.html#ga52f3988c4f71fd24ca3c55e74fbc51cf", null ],
    [ "setInterval", "d5/d6f/group__BLE__Scanner.html#ga28d82755c5283c160a0a1dfd10010a7b", null ],
    [ "setScannerCallback", "d5/d6f/group__BLE__Scanner.html#ga87e2340d9ef4380f882a50414bb5fee4", null ]
];