var group__Cli__Version =
[
    [ "get", "d0/df4/group__Cli__Version.html#ga4b12316c54a2a1cc6f4720664ccd7979", null ]
];