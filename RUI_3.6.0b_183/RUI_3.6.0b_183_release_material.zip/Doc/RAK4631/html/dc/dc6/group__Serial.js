var group__Serial =
[
    [ "begin", "dc/dc6/group__Serial.html#gaa667be774996900a314fcaae87e2b216", null ],
    [ "end", "dc/dc6/group__Serial.html#ga081b5c662ecee58405a543518f699d31", null ],
    [ "lock", "dc/dc6/group__Serial.html#ga47c702da390e8b0657539777f4fff56b", null ],
    [ "password", "dc/dc6/group__Serial.html#ga8dae286d1dcb4f3fdda25fb5ff3049f8", null ],
    [ "write", "dc/dc6/group__Serial.html#ga6ee174e74a6d460c4327c42f74ddc62b", null ],
    [ "available", "dc/dc6/group__Serial.html#gaeec8f4dbef97221a6041d6cdc6e9b716", null ],
    [ "read", "dc/dc6/group__Serial.html#gaead319e2866cf90d56c10f2ed39a4396", null ],
    [ "peek", "dc/dc6/group__Serial.html#ga65e3a688fcd31f2f486d3af02c400d8f", null ],
    [ "flush", "dc/dc6/group__Serial.html#ga0a4efd3d0f68d057f23eb5dfcd16c17c", null ],
    [ "print", "dc/dc6/group__Serial.html#ga447df1d390c7dc8af70f7e684963b212", null ],
    [ "println", "dc/dc6/group__Serial.html#ga058fbcd23e761e3d2fbe06bb1a07b737", null ],
    [ "printf", "dc/dc6/group__Serial.html#ga797e66b90cabc46d1921fbd35cb0bcea", null ],
    [ "setTimeout", "dc/dc6/group__Serial.html#ga76c7d6530b9cb17f6663a64aea84b61e", null ],
    [ "getTimeout", "dc/dc6/group__Serial.html#ga3706a766b0c864251f126fceda9913e1", null ],
    [ "readBytes", "dc/dc6/group__Serial.html#gada0b9486ea1fe7b8d4aab8f04f5607ee", null ],
    [ "readBytesUntil", "dc/dc6/group__Serial.html#ga9aa68dc2abab64ceafe8d8745b728af2", null ],
    [ "readString", "dc/dc6/group__Serial.html#gab1b0d4ef00718d18fe34d35dd1e26c66", null ],
    [ "readStringUntil", "dc/dc6/group__Serial.html#gac1f2b6e32ae2e321ad98c16482edf96a", null ]
];