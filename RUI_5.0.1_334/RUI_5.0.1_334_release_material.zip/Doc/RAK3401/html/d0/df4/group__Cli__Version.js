var group__Cli__Version =
[
    [ "RAKSystem::cliVersion::get", "d0/df4/group__Cli__Version.html#gac5f5202af3bb4156a22175cb76becb91", null ],
    [ "RAKSystem::cliVersion::set", "d0/df4/group__Cli__Version.html#gaa7b03a182081ec7a7251bf4f7a3c127b", null ]
];