#ifndef _ATCMD_MISC_DEF_H_
#define _ATCMD_MISC_DEF_H_

#define ATCMD_FACTORY               "AT+FACTORY"

#endif //_ATCMD_MISC_DEF_H_
