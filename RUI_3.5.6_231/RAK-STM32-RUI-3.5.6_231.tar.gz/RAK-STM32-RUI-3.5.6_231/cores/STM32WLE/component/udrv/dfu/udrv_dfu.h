#ifndef _UDRV_DFU_H_
#define _UDRV_DFU_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

void udrv_enter_dfu (void);

#ifdef __cplusplus
}
#endif

#endif  // #ifndef _UDRV_DFU_H_
