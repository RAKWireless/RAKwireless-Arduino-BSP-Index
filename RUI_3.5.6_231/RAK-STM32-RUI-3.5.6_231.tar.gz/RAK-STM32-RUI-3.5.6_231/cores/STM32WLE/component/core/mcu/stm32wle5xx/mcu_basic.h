#ifndef __MCU_BASIC_H__
#define __MCU_BASIC_H__

#define MCU_SYS_CONFIG_NVM_ADDR           0x0803F000
#define MCU_USER_DATA_NVM_ADDR            0x08037800
#define MCU_FACTORY_DEFAULT_NVM_ADDR      0x08037000

#endif
