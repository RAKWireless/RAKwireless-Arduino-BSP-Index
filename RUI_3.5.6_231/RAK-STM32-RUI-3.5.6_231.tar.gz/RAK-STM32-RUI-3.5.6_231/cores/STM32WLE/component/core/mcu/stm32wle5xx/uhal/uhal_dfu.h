#ifndef _UHAL_DFU_H_
#define _UHAL_DFU_H_

#include <stdint.h>
#include <stddef.h>
#include "stm32wle5xx.h"

void uhal_enter_dfu (void);

#endif  // #ifndef _UHAL_DFU_H_
