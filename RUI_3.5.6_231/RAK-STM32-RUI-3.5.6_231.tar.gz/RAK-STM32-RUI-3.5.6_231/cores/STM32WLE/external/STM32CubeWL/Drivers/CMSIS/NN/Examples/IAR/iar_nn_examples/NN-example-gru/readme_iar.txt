CMSIS NN Lib example arm_nnexample_gru0 for
  Cortex-M0, Cortex-M3, Cortex-M4 and Cortex-M7.

The example is configured for IAR Embedded Workbench for ARM Simulator.

When changing target, remember to change the ARM_MATH_CMx and __FPU_PRESENT
Preprocessor defines for C/C++ Compiler