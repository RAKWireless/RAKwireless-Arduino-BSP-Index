#ifndef __WIRING_H__
#define __WIRING_H__

#include "wiring_time.h"

#endif // __WIRING_H__
