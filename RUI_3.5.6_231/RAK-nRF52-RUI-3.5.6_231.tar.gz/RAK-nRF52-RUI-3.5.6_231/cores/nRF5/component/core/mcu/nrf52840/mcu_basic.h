#ifndef __MCU_BASIC_H__
#define __MCU_BASIC_H__

#define MCU_SYS_CONFIG_NVM_ADDR           0x000D0000
#define MCU_USER_DATA_NVM_ADDR            0x000B0000
#define MCU_FACTORY_DEFAULT_NVM_ADDR      0x000AF000

#endif
