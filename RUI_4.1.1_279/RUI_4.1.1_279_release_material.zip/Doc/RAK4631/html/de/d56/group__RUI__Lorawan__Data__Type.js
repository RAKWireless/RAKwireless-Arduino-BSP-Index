var group__RUI__Lorawan__Data__Type =
[
    [ "RAKLoraP2P", "d8/da8/classRAKLoraP2P.html", [
      [ "RAKLoraP2P", "de/d56/group__RUI__Lorawan__Data__Type.html#ga16017aceba9b637180e264c4e410c802", null ],
      [ "precv", "da/d90/group__P2P.html#ga19fae132ae002e3a85db048b985b4c09", null ],
      [ "psend", "da/d90/group__P2P.html#gaa25cb63248703c23ee37b08a4e678faf", null ],
      [ "psend", "de/d56/group__RUI__Lorawan__Data__Type.html#ga9c123e132f12982eaf15dbcc3e795eb9", null ],
      [ "registerPRecvCallback", "da/d90/group__P2P.html#gac895902f47eea2c781694655b890822f", null ],
      [ "registerPSendCallback", "da/d90/group__P2P.html#gadee9ffd40892410c24336c1cd16b8f5a", null ],
      [ "registerPSendCADCallback", "da/d90/group__P2P.html#ga885de1a1e3618cc9dbf953b7ecedcd81", null ],
      [ "iqInver", "de/d56/group__RUI__Lorawan__Data__Type.html#gadbe5448b21c73b7771f0f63bb657053b", null ],
      [ "syncword", "de/d56/group__RUI__Lorawan__Data__Type.html#ga652a2465541aa497f68e1e4281890073", null ],
      [ "rfFrequency", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7bd30bc7a5f4ba3fe21d34a2828caaa0", null ],
      [ "txOutputPower", "de/d56/group__RUI__Lorawan__Data__Type.html#ga1e27bec3900515642d8d8e5758af484e", null ],
      [ "bandwidth", "de/d56/group__RUI__Lorawan__Data__Type.html#gafd12eaaa8c52eb3fc5343aac8ee957e7", null ],
      [ "speradingFactor", "de/d56/group__RUI__Lorawan__Data__Type.html#gae4020faa1144f6df1b792462cd64b783", null ],
      [ "codingrate", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7dc745794c81f0e6cd15bb98449b71c5", null ],
      [ "preambleLength", "de/d56/group__RUI__Lorawan__Data__Type.html#ga3c3e21b522152e8f90c588fbb2b78667", null ],
      [ "symbolTimeout", "de/d56/group__RUI__Lorawan__Data__Type.html#ga903790f622e90e8754dc6d9391666f51", null ],
      [ "fixLengthPayload", "de/d56/group__RUI__Lorawan__Data__Type.html#gad4e43af408e69c81bb81b66c758f3269", null ],
      [ "cad", "de/d56/group__RUI__Lorawan__Data__Type.html#gaafc186ad0568fbdc9529971870230bb3", null ],
      [ "pfreq", "de/d56/group__RUI__Lorawan__Data__Type.html#gae7e9e094ee36afc914b56ebe369c0d41", null ],
      [ "psf", "de/d56/group__RUI__Lorawan__Data__Type.html#ga6b1b41d64d2cb3e097c50a378b4b1921", null ],
      [ "pbw", "de/d56/group__RUI__Lorawan__Data__Type.html#gad0f049124e5a7926361420a812bec7f3", null ],
      [ "pcr", "de/d56/group__RUI__Lorawan__Data__Type.html#ga6a3a27f1b5c6016815705e9ff725194f", null ],
      [ "ppl", "de/d56/group__RUI__Lorawan__Data__Type.html#gad30a5a2b17bdb6ffe05cac559301c64d", null ],
      [ "ptp", "de/d56/group__RUI__Lorawan__Data__Type.html#ga472c85298d6f67c916565bd866fd90ed", null ],
      [ "encry", "de/d56/group__RUI__Lorawan__Data__Type.html#ga0442d9ec54c44689f1bbb06a7b61ee55", null ],
      [ "enckey", "de/d56/group__RUI__Lorawan__Data__Type.html#gab20fe9fc835067d3435a54d1bb2b7cf9", null ],
      [ "enciv", "de/d56/group__RUI__Lorawan__Data__Type.html#ga72f13ea96cc718c770bf9f10ee09c9e8", null ],
      [ "pbr", "de/d56/group__RUI__Lorawan__Data__Type.html#ga24ffcc3ef01cdd0c129a5e5966b6a907", null ],
      [ "pfdev", "de/d56/group__RUI__Lorawan__Data__Type.html#ga2251e39055b5797602029f461d68c932", null ],
      [ "nwm", "de/d56/group__RUI__Lorawan__Data__Type.html#ga0b95ce11a2a1f1af59c8e82df961d463", null ]
    ] ],
    [ "nwm", "dd/daa/classRAKLoraP2P_1_1nwm.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga84a9cd93622aa531274dd4c027f006ce", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga0cc473e8c4243c33c431494d3cfd0e31", null ]
    ] ],
    [ "cad", "d9/d3b/classRAKLoraP2P_1_1cad.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5a0ac596ad458f81229cb3b8542c99a7", null ]
    ] ],
    [ "fixLengthPayload", "d4/db5/classRAKLoraP2P_1_1fixLengthPayload.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5a0ac596ad458f81229cb3b8542c99a7", null ]
    ] ],
    [ "symbolTimeout", "da/d95/classRAKLoraP2P_1_1symbolTimeout.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaf27fd3bf5132a7da2c6d48d11605beee", null ]
    ] ],
    [ "preambleLength", "dd/d50/classRAKLoraP2P_1_1preambleLength.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#gae1d27f0bc8dfb970f6caec636ad3730c", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga9acd28f0b3cedc10ca55e404a70b3a42", null ]
    ] ],
    [ "codingrate", "df/d67/classRAKLoraP2P_1_1codingrate.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7078407bba64d8341d38f517836858f1", null ]
    ] ],
    [ "speradingFactor", "df/dcd/classRAKLoraP2P_1_1speradingFactor.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga67f3e32e8dee8c91ea7d8c3edfd4c828", null ]
    ] ],
    [ "bandwidth", "dd/dc0/classRAKLoraP2P_1_1bandwidth.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gae837384d7164d542f3bf871a8155fadc", null ]
    ] ],
    [ "txOutputPower", "d7/da2/classRAKLoraP2P_1_1txOutputPower.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaba3a03ff0742e917d9b79aaf70e55907", null ]
    ] ],
    [ "rfFrequency", "d6/dcf/classRAKLoraP2P_1_1rfFrequency.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gacd34fd452f595ba9c5db4cea370c474a", null ]
    ] ],
    [ "syncword", "d4/d12/classRAKLoraP2P_1_1syncword.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaa785129535a31eb87792edc5eebe38c7", null ]
    ] ],
    [ "iqInver", "d3/d49/classRAKLoraP2P_1_1iqInver.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7e43fc01bd6ae68ce2723c708c47e47d", null ]
    ] ],
    [ "pfdev", "d0/dea/classRAKLoraP2P_1_1pfdev.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8f1d843b0ba831cac81383863c4da4bb", null ]
    ] ],
    [ "pbr", "df/d2d/classRAKLoraP2P_1_1pbr.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8f1d843b0ba831cac81383863c4da4bb", null ]
    ] ],
    [ "enciv", "d6/dff/classRAKLoraP2P_1_1enciv.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga192d3b873a2d0f736adbba71d8f20e48", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5c6145ab98c5c5437b9cdce4b417c1ba", null ]
    ] ],
    [ "enckey", "de/da2/classRAKLoraP2P_1_1enckey.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga192d3b873a2d0f736adbba71d8f20e48", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5c6145ab98c5c5437b9cdce4b417c1ba", null ]
    ] ],
    [ "encry", "d9/d8e/classRAKLoraP2P_1_1encry.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga2ad670093a7069096af27a4e231540a4", null ]
    ] ],
    [ "ptp", "da/d98/classRAKLoraP2P_1_1ptp.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gac3bbc06f12ee4803c554efae5bc32d0b", null ]
    ] ],
    [ "ppl", "d6/df2/classRAKLoraP2P_1_1ppl.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#gae1d27f0bc8dfb970f6caec636ad3730c", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaca89edf57acf3d7a409f46f9caa82df5", null ]
    ] ],
    [ "pcr", "d8/df5/classRAKLoraP2P_1_1pcr.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gac3bbc06f12ee4803c554efae5bc32d0b", null ]
    ] ],
    [ "pbw", "d7/dd8/classRAKLoraP2P_1_1pbw.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8f1d843b0ba831cac81383863c4da4bb", null ]
    ] ],
    [ "psf", "d6/dcc/classRAKLoraP2P_1_1psf.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gac3bbc06f12ee4803c554efae5bc32d0b", null ]
    ] ],
    [ "pfreq", "dc/dc8/classRAKLoraP2P_1_1pfreq.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8f1d843b0ba831cac81383863c4da4bb", null ]
    ] ],
    [ "RAK_LORA_McSession", "df/d1f/structRAK__LORA__McSession.html", [
      [ "McDevclass", "df/d1f/structRAK__LORA__McSession.html#a8880c6395ab3e45bfdb3ff4153764e3e", null ],
      [ "McAddress", "df/d1f/structRAK__LORA__McSession.html#a91d59aabc7b3cf1524cff9dfa3ff0f4f", null ],
      [ "McAppSKey", "df/d1f/structRAK__LORA__McSession.html#a3e5410de49004f5bf990b10e4902e00f", null ],
      [ "McNwkSKey", "df/d1f/structRAK__LORA__McSession.html#a3e42e3e105838ca7d1cf6cadbab6ac0b", null ],
      [ "McFrequency", "df/d1f/structRAK__LORA__McSession.html#a5df76ee656aad7c54e40fbd9d572d285", null ],
      [ "McDatarate", "df/d1f/structRAK__LORA__McSession.html#a76c6c14c005e0155001047886ff5d14a", null ],
      [ "McPeriodicity", "df/d1f/structRAK__LORA__McSession.html#aee13d3d2aba615042dd92bd1f43cde37", null ],
      [ "McGroupID", "df/d1f/structRAK__LORA__McSession.html#a1fbcc23862f1d55f67519f6ad7a8cbb7", null ],
      [ "entry", "df/d1f/structRAK__LORA__McSession.html#adbdb38b7f14c384804844026547a276e", null ]
    ] ],
    [ "RAK_LORA_chan_rssi", "d1/d81/structRAK__LORA__chan__rssi.html", [
      [ "chan", "d1/d81/structRAK__LORA__chan__rssi.html#afb67f3e4e204785118073a96b76614d6", null ],
      [ "mask", "d1/d81/structRAK__LORA__chan__rssi.html#a7fd850d4bb04f7410e8e2abf5f349348", null ],
      [ "rssi", "d1/d81/structRAK__LORA__chan__rssi.html#a3b962e67ba74725bd60ca3c29f785abe", null ]
    ] ],
    [ "RAKLoRaMacEventInfoStatus_t", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7c9f18e5d84b31eb120215ede3a57df1", null ],
    [ "RAK_LORA_BAND", "de/d56/group__RUI__Lorawan__Data__Type.html#ga4b8c367e751e52fdb9bf0daeb01f501b", [
      [ "RAK_REGION_EU433", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba1fbeaac26403fc93d4ca51dbae407a72", null ],
      [ "RAK_REGION_CN470", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba62d066d2c1686b8df226cd43adec850f", null ],
      [ "RAK_REGION_RU864", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba193a6f81065ed5059d31966f717625d6", null ],
      [ "RAK_REGION_IN865", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501baa55ac5d51e0d00d86d4ad6f35d72534f", null ],
      [ "RAK_REGION_EU868", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501baf251060a5ebbd49acdfa9ee459c6ab16", null ],
      [ "RAK_REGION_US915", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501baf51e8c3353b5773cd81ffa31ca8de950", null ],
      [ "RAK_REGION_AU915", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba9d01575b3d4697a4ba78f9f13d04824e", null ],
      [ "RAK_REGION_KR920", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501bac221eb115d632600c809ea947d5d24eb", null ],
      [ "RAK_REGION_AS923", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba09f40ae957af953e8a57002d9e6acbb6", null ],
      [ "RAK_REGION_AS923_2", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba240eceec7e7ca12ae5519c4bab1eb195", null ],
      [ "RAK_REGION_AS923_3", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba0941ee7356d71245ae712bd22b095c83", null ],
      [ "RAK_REGION_AS923_4", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba42a4150d94f2cf9ec62ca7432f07b36a", null ],
      [ "RAK_REGION_LA915", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501baa722a0442c2d43bf6ad210e6ed471c6e", null ]
    ] ],
    [ "RAK_LORA_JOIN_MODE", "de/d56/group__RUI__Lorawan__Data__Type.html#gae0315aed26d67c63ae036a2b8f6a58ab", [
      [ "RAK_LORA_ABP", "de/d56/group__RUI__Lorawan__Data__Type.html#ggae0315aed26d67c63ae036a2b8f6a58abac955cb4a6f6e20996e3335f33ab6e88a", null ],
      [ "RAK_LORA_OTAA", "de/d56/group__RUI__Lorawan__Data__Type.html#ggae0315aed26d67c63ae036a2b8f6a58aba561f1f24597f9b4b58c887b7594dc6ea", null ]
    ] ],
    [ "RAK_LORA_CONFIRM_MODE", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8fde2d1fa94b843144063b2f56260d2d", [
      [ "RAK_LORA_NO_ACK", "de/d56/group__RUI__Lorawan__Data__Type.html#gga8fde2d1fa94b843144063b2f56260d2da67023bb91de2fe123df48ef47b71ae2c", null ],
      [ "RAK_LORA_ACK", "de/d56/group__RUI__Lorawan__Data__Type.html#gga8fde2d1fa94b843144063b2f56260d2dae26518a000ed7ae5371a190691b014f1", null ]
    ] ],
    [ "RAK_LORA_CLASS", "de/d56/group__RUI__Lorawan__Data__Type.html#gab23a5817dcc95b55ac49f9ed52b660fe", [
      [ "RAK_LORA_CLASS_A", "de/d56/group__RUI__Lorawan__Data__Type.html#ggab23a5817dcc95b55ac49f9ed52b660fea65004a128fd53f1742be4fcf6a7cf1df", null ],
      [ "RAK_LORA_CLASS_B", "de/d56/group__RUI__Lorawan__Data__Type.html#ggab23a5817dcc95b55ac49f9ed52b660fea701e64d10dd68f6dc8636bd2164fe2b2", null ],
      [ "RAK_LORA_CLASS_C", "de/d56/group__RUI__Lorawan__Data__Type.html#ggab23a5817dcc95b55ac49f9ed52b660fea20757f4cfcb9c4b21465301bc30032ac", null ]
    ] ],
    [ "RAKLoRaMacEventInfoStatus", "de/d56/group__RUI__Lorawan__Data__Type.html#ga53f1efae54b75e1f18dec7915d51698b", [
      [ "RAK_LORAMAC_STATUS_OK", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698badd796e307116e1bf02bfeb049a962e47", null ],
      [ "RAK_LORAMAC_STATUS_ERROR", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba41f9d09859f89f8aa8f76c71f8eb4824", null ],
      [ "RAK_LORAMAC_STATUS_TX_TIMEOUT", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba52c30dd888678a2b974cfbd4d5cd1222", null ],
      [ "RAK_LORAMAC_STATUS_RX1_TIMEOUT", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba8dff955e2757aaa744ea612459e9946c", null ],
      [ "RAK_LORAMAC_STATUS_RX2_TIMEOUT", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba76b51a1130c5239441382a51743c8d18", null ],
      [ "RAK_LORAMAC_STATUS_RX1_ERROR", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba619de482c592cec40ea31902a25a0380", null ],
      [ "RAK_LORAMAC_STATUS_RX2_ERROR", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba6c7d939b905c09c9aa3b06404bab87a4", null ],
      [ "RAK_LORAMAC_STATUS_JOIN_FAIL", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698baa261e7da5a641017a561ba00d720eea3", null ],
      [ "RAK_LORAMAC_STATUS_DOWNLINK_REPEATED", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698bae1dd65677cb18aa2dc7a68f8102e5b90", null ],
      [ "RAK_LORAMAC_STATUS_TX_DR_PAYLOAD_SIZE_ERROR", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba7e06cb151622c2d9459bee3d90f9d418", null ],
      [ "RAK_LORAMAC_STATUS_DOWNLINK_TOO_MANY_FRAMES_LOSS", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba2cc06e5658de74f75b8ec3e04b0b1dab", null ],
      [ "RAK_LORAMAC_STATUS_ADDRESS_FAIL", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba27b84ae0bbabed76a1d69d38fc3584e2", null ],
      [ "RAK_LORAMAC_STATUS_MIC_FAIL", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698bacb434cbbe90365e153a5a4ed16925def", null ],
      [ "RAK_LORAMAC_STATUS_MULTICAST_FAIL", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba51740bcd2e2f8c8a00176525a77a1ed8", null ],
      [ "RAK_LORAMAC_STATUS_BEACON_LOCKED", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698badf3f899f0ae4662efcafe9ae621b980e", null ],
      [ "RAK_LORAMAC_STATUS_BEACON_LOST", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698babe5246e1f615cc505c131455976352ff", null ],
      [ "RAK_LORAMAC_STATUS_BEACON_NOT_FOUND", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba16c819ec8e4226b009d29e6a540fc76b", null ]
    ] ],
    [ "RAKLoraP2P", "de/d56/group__RUI__Lorawan__Data__Type.html#ga16017aceba9b637180e264c4e410c802", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8f1d843b0ba831cac81383863c4da4bb", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gac3bbc06f12ee4803c554efae5bc32d0b", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8f1d843b0ba831cac81383863c4da4bb", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gac3bbc06f12ee4803c554efae5bc32d0b", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#gae1d27f0bc8dfb970f6caec636ad3730c", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaca89edf57acf3d7a409f46f9caa82df5", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gac3bbc06f12ee4803c554efae5bc32d0b", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga2ad670093a7069096af27a4e231540a4", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga192d3b873a2d0f736adbba71d8f20e48", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5c6145ab98c5c5437b9cdce4b417c1ba", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga192d3b873a2d0f736adbba71d8f20e48", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5c6145ab98c5c5437b9cdce4b417c1ba", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8f1d843b0ba831cac81383863c4da4bb", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8f1d843b0ba831cac81383863c4da4bb", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7e43fc01bd6ae68ce2723c708c47e47d", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaa785129535a31eb87792edc5eebe38c7", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gacd34fd452f595ba9c5db4cea370c474a", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaba3a03ff0742e917d9b79aaf70e55907", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gae837384d7164d542f3bf871a8155fadc", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga67f3e32e8dee8c91ea7d8c3edfd4c828", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7078407bba64d8341d38f517836858f1", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#gae1d27f0bc8dfb970f6caec636ad3730c", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga9acd28f0b3cedc10ca55e404a70b3a42", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaf27fd3bf5132a7da2c6d48d11605beee", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5a0ac596ad458f81229cb3b8542c99a7", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5a0ac596ad458f81229cb3b8542c99a7", null ],
    [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga84a9cd93622aa531274dd4c027f006ce", null ],
    [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga0cc473e8c4243c33c431494d3cfd0e31", null ],
    [ "psend", "de/d56/group__RUI__Lorawan__Data__Type.html#ga9c123e132f12982eaf15dbcc3e795eb9", null ],
    [ "iqInver", "de/d56/group__RUI__Lorawan__Data__Type.html#gadbe5448b21c73b7771f0f63bb657053b", null ],
    [ "syncword", "de/d56/group__RUI__Lorawan__Data__Type.html#ga652a2465541aa497f68e1e4281890073", null ],
    [ "rfFrequency", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7bd30bc7a5f4ba3fe21d34a2828caaa0", null ],
    [ "txOutputPower", "de/d56/group__RUI__Lorawan__Data__Type.html#ga1e27bec3900515642d8d8e5758af484e", null ],
    [ "bandwidth", "de/d56/group__RUI__Lorawan__Data__Type.html#gafd12eaaa8c52eb3fc5343aac8ee957e7", null ],
    [ "speradingFactor", "de/d56/group__RUI__Lorawan__Data__Type.html#gae4020faa1144f6df1b792462cd64b783", null ],
    [ "codingrate", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7dc745794c81f0e6cd15bb98449b71c5", null ],
    [ "preambleLength", "de/d56/group__RUI__Lorawan__Data__Type.html#ga3c3e21b522152e8f90c588fbb2b78667", null ],
    [ "symbolTimeout", "de/d56/group__RUI__Lorawan__Data__Type.html#ga903790f622e90e8754dc6d9391666f51", null ],
    [ "fixLengthPayload", "de/d56/group__RUI__Lorawan__Data__Type.html#gad4e43af408e69c81bb81b66c758f3269", null ],
    [ "cad", "de/d56/group__RUI__Lorawan__Data__Type.html#gaafc186ad0568fbdc9529971870230bb3", null ],
    [ "pfreq", "de/d56/group__RUI__Lorawan__Data__Type.html#gae7e9e094ee36afc914b56ebe369c0d41", null ],
    [ "psf", "de/d56/group__RUI__Lorawan__Data__Type.html#ga6b1b41d64d2cb3e097c50a378b4b1921", null ],
    [ "pbw", "de/d56/group__RUI__Lorawan__Data__Type.html#gad0f049124e5a7926361420a812bec7f3", null ],
    [ "pcr", "de/d56/group__RUI__Lorawan__Data__Type.html#ga6a3a27f1b5c6016815705e9ff725194f", null ],
    [ "ppl", "de/d56/group__RUI__Lorawan__Data__Type.html#gad30a5a2b17bdb6ffe05cac559301c64d", null ],
    [ "ptp", "de/d56/group__RUI__Lorawan__Data__Type.html#ga472c85298d6f67c916565bd866fd90ed", null ],
    [ "encry", "de/d56/group__RUI__Lorawan__Data__Type.html#ga0442d9ec54c44689f1bbb06a7b61ee55", null ],
    [ "enckey", "de/d56/group__RUI__Lorawan__Data__Type.html#gab20fe9fc835067d3435a54d1bb2b7cf9", null ],
    [ "enciv", "de/d56/group__RUI__Lorawan__Data__Type.html#ga72f13ea96cc718c770bf9f10ee09c9e8", null ],
    [ "pbr", "de/d56/group__RUI__Lorawan__Data__Type.html#ga24ffcc3ef01cdd0c129a5e5966b6a907", null ],
    [ "pfdev", "de/d56/group__RUI__Lorawan__Data__Type.html#ga2251e39055b5797602029f461d68c932", null ],
    [ "nwm", "de/d56/group__RUI__Lorawan__Data__Type.html#ga0b95ce11a2a1f1af59c8e82df961d463", null ]
];