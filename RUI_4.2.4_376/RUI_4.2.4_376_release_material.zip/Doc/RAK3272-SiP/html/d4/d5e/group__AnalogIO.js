var group__AnalogIO =
[
    [ "analogRead", "d4/d5e/group__AnalogIO.html#ga2eda513a6bb35bf13675a24711d4e864", null ],
    [ "analogReference", "d4/d5e/group__AnalogIO.html#ga800f543c8525eeaf7d0b74ab7099188e", null ],
    [ "analogOversampling", "d4/d5e/group__AnalogIO.html#ga0c2d6d7a780f5592565e1d0fc0565108", null ],
    [ "analogWrite", "d4/d5e/group__AnalogIO.html#ga448d31050a4a66a2545c0f7857332a0d", null ],
    [ "analogReadResolution", "d4/d5e/group__AnalogIO.html#ga0898de532d6f7e0c1a870068b6827a4d", null ],
    [ "analogWriteResolution", "d4/d5e/group__AnalogIO.html#ga20dc001acdcca063c7e09bd90a30c027", null ]
];