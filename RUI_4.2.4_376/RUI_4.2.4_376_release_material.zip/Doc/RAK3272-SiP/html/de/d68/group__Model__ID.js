var group__Model__ID =
[
    [ "RAKSystem::modelId::get", "de/d68/group__Model__ID.html#gac5f5202af3bb4156a22175cb76becb91", null ],
    [ "RAKSystem::modelId::set", "de/d68/group__Model__ID.html#gad8d687d08dfce1324c6f9cb8533d7fa5", null ]
];