var modules =
[
    [ "Arduino Api", "d2/d9c/group__ruiapi.html", "d2/d9c/group__ruiapi" ],
    [ "System", "dd/d1a/group__System.html", "dd/d1a/group__System" ],
    [ "Lorawan", "d5/d00/group__lorawan.html", "d5/d00/group__lorawan" ],
    [ "Ble", "d7/d19/group__ble.html", "d7/d19/group__ble" ],
    [ "Nfc", "dc/d4d/group__NFC.html", "dc/d4d/group__NFC" ],
    [ "One Wire Serial", "d2/d37/group__One__Wire__Serial.html", "d2/d37/group__One__Wire__Serial" ],
    [ "API Mode", "db/d0a/group__Api__Mode.html", "db/d0a/group__Api__Mode" ]
];