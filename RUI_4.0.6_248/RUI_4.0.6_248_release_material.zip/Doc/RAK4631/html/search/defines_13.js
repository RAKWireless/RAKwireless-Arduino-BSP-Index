var searchData=
[
  ['word',['word',['../d1/d9d/dataConversion_8h.html#a5487d1c0ecfed21733f7b13a06cffc5e',1,'dataConversion.h']]]
];
