var searchData=
[
  ['g_5fdate_5ftime',['g_date_time',['../d2/de5/module__handler_8h.html#a0c56144f5af5bae83d4b52bfad352555',1,'module_handler.h']]],
  ['g_5fdev_5fname',['g_dev_name',['../d1/db7/RUI3-Power-Test_2src_2main_8h.html#a1bf466092b3d1e592799c672ac09d7ec',1,'g_dev_name():&#160;main.h'],['../dd/d3a/RUI3-Sensor-Node_2src_2main_8h.html#a1bf466092b3d1e592799c672ac09d7ec',1,'g_dev_name():&#160;main.h']]],
  ['g_5fhas_5frak15001',['g_has_rak15001',['../dd/d3a/RUI3-Sensor-Node_2src_2main_8h.html#ad744c88e2cf2124a43acb056d48de728',1,'main.h']]],
  ['g_5florawan_5fsettings',['g_lorawan_settings',['../dd/d3a/RUI3-Sensor-Node_2src_2main_8h.html#a6714cb681e6454247918083e2a019c1b',1,'main.h']]],
  ['g_5fsend_5frepeat_5ftime',['g_send_repeat_time',['../d1/db7/RUI3-Power-Test_2src_2main_8h.html#ad1b03ec7e5edf62bc17122a54c7f1ebd',1,'main.h']]],
  ['g_5fsolution_5fdata',['g_solution_data',['../d1/db7/RUI3-Power-Test_2src_2main_8h.html#a7609c8caed6f9fb81804bc73d9265261',1,'g_solution_data():&#160;main.h'],['../d2/de5/module__handler_8h.html#a7609c8caed6f9fb81804bc73d9265261',1,'g_solution_data():&#160;module_handler.h']]],
  ['gateway_5fid',['gateway_ID',['../dd/d3a/structsbeacon__bgw.html#a4511ca52693b6a7360221cdbac8f5d0a',1,'sbeacon_bgw']]],
  ['gmi',['gmi',['../d4/d46/classbg77.html#a7aeb7025ba02ad0afec04c5dcf3c1bef',1,'bg77']]],
  ['gmm',['gmm',['../d4/d46/classbg77.html#a2606572f3fad2212abc8304e3cda49bc',1,'bg77']]],
  ['gmr',['gmr',['../d4/d46/classbg77.html#af04330cb485d7b3afac7007b3fdb32dc',1,'bg77']]],
  ['gnss_5factive',['gnss_active',['../d2/de5/module__handler_8h.html#a1a05db7d900fecd44f1d7596b1193380',1,'module_handler.h']]],
  ['gnss_5fformat',['gnss_format',['../d2/de5/module__handler_8h.html#a8d76d1c5155abeb240745f3760a7ed34',1,'module_handler.h']]],
  ['gps_5fcoordinate',['GPS_coordinate',['../dd/d3a/structsbeacon__bgw.html#a414e967ae9803d02cf58277d0d4fb562',1,'sbeacon_bgw']]],
  ['groupid',['GroupID',['../d7/dd9/structMcSession__s.html#a3c2cab035f18b4d30fff7426eb5722ff',1,'McSession_s']]],
  ['gsn',['gsn',['../d4/d46/classbg77.html#a20bde58546c348101103b6800c334192',1,'bg77']]]
];
