var group__LPS22HB =
[
    [ "init", "d9/d36/group__LPS22HB.html#ga988e7824fd6ad20a5ad876f9438cded8", null ],
    [ "pressure", "d9/d36/group__LPS22HB.html#ga459a36af0304dc2ce59c1795fe9a073e", null ]
];