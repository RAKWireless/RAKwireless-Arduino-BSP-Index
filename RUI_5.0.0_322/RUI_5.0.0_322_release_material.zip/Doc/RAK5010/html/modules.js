var modules =
[
    [ "Arduino Api", "d2/d9c/group__ruiapi.html", "d2/d9c/group__ruiapi" ],
    [ "System", "dd/d1a/group__System.html", "dd/d1a/group__System" ],
    [ "Ble", "d7/d19/group__ble.html", "d7/d19/group__ble" ],
    [ "One Wire Serial", "d2/d37/group__One__Wire__Serial.html", "d2/d37/group__One__Wire__Serial" ],
    [ "API Mode", "db/d0a/group__Api__Mode.html", "db/d0a/group__Api__Mode" ],
    [ "Sensors", "d9/dfd/group__Sensors.html", "d9/dfd/group__Sensors" ],
    [ "NVM context management implementation", "d2/d27/group__NVMDATAMGMT.html", "d2/d27/group__NVMDATAMGMT" ],
    [ "Watchdog", "df/d11/group__Watchdog.html", "df/d11/group__Watchdog" ]
];