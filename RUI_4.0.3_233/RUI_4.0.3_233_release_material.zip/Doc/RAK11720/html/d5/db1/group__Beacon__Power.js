var group__Beacon__Power =
[
    [ "set", "d5/db1/group__Beacon__Power.html#ga24514a2dd48d151061d66af2b13c783b", null ]
];