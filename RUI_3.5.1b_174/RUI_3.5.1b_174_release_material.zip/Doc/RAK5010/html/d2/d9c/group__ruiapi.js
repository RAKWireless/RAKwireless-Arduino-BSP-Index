var group__ruiapi =
[
    [ "RUI Arduino Data Type", "da/dc1/group__RUI__Arduino__Data__Type.html", "da/dc1/group__RUI__Arduino__Data__Type" ],
    [ "Serial", "dc/dc6/group__Serial.html", "dc/dc6/group__Serial" ],
    [ "Wire", "d7/dae/group__Wire.html", "d7/dae/group__Wire" ],
    [ "Time", "d0/dd5/group__Time.html", "d0/dd5/group__Time" ],
    [ "AdvancedIO", "da/daf/group__AdvancedIO.html", "da/daf/group__AdvancedIO" ],
    [ "Characters", "db/dfa/group__Characters.html", "db/dfa/group__Characters" ],
    [ "Bit and Byte", "d1/d39/group__Bit__and__Byte.html", "d1/d39/group__Bit__and__Byte" ],
    [ "DigitalIO", "d8/d8f/group__DigitalIO.html", "d8/d8f/group__DigitalIO" ],
    [ "AnalogIO", "d4/d5e/group__AnalogIO.html", "d4/d5e/group__AnalogIO" ],
    [ "Interrupts", "d9/d7f/group__Interrupts.html", "d9/d7f/group__Interrupts" ],
    [ "RandomNumber", "d1/d05/group__Random.html", "d1/d05/group__Random" ]
];