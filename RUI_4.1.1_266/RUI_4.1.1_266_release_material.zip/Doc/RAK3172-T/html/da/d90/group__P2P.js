var group__P2P =
[
    [ "pfreq", "dc/dc8/classRAKLoraP2P_1_1pfreq.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8f1d843b0ba831cac81383863c4da4bb", null ]
    ] ],
    [ "psf", "d6/dcc/classRAKLoraP2P_1_1psf.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gac3bbc06f12ee4803c554efae5bc32d0b", null ]
    ] ],
    [ "pbw", "d7/dd8/classRAKLoraP2P_1_1pbw.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8f1d843b0ba831cac81383863c4da4bb", null ]
    ] ],
    [ "pcr", "d8/df5/classRAKLoraP2P_1_1pcr.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gac3bbc06f12ee4803c554efae5bc32d0b", null ]
    ] ],
    [ "ppl", "d6/df2/classRAKLoraP2P_1_1ppl.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#gae1d27f0bc8dfb970f6caec636ad3730c", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gaca89edf57acf3d7a409f46f9caa82df5", null ]
    ] ],
    [ "ptp", "da/d98/classRAKLoraP2P_1_1ptp.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#gac3bbc06f12ee4803c554efae5bc32d0b", null ]
    ] ],
    [ "encry", "d9/d8e/classRAKLoraP2P_1_1encry.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7fbabc63e6e4118d07f087d72aa068f4", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga2ad670093a7069096af27a4e231540a4", null ]
    ] ],
    [ "enckey", "de/da2/classRAKLoraP2P_1_1enckey.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga192d3b873a2d0f736adbba71d8f20e48", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5c6145ab98c5c5437b9cdce4b417c1ba", null ]
    ] ],
    [ "pbr", "df/d2d/classRAKLoraP2P_1_1pbr.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8f1d843b0ba831cac81383863c4da4bb", null ]
    ] ],
    [ "pfdev", "d0/dea/classRAKLoraP2P_1_1pfdev.html", [
      [ "get", "de/d56/group__RUI__Lorawan__Data__Type.html#ga5402a7d76c406b44d7d509f55d6af8cb", null ],
      [ "set", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8f1d843b0ba831cac81383863c4da4bb", null ]
    ] ],
    [ "nwm", "d3/d90/classRAKLorawan_1_1nwm.html", [
      [ "get", "d3/d90/classRAKLorawan_1_1nwm.html#a84a9cd93622aa531274dd4c027f006ce", null ],
      [ "set", "d3/d90/classRAKLorawan_1_1nwm.html#a0cc473e8c4243c33c431494d3cfd0e31", null ]
    ] ],
    [ "precv", "da/d90/group__P2P.html#ga19fae132ae002e3a85db048b985b4c09", null ],
    [ "psend", "da/d90/group__P2P.html#gaa25cb63248703c23ee37b08a4e678faf", null ],
    [ "registerPRecvCallback", "da/d90/group__P2P.html#gac895902f47eea2c781694655b890822f", null ],
    [ "registerPSendCallback", "da/d90/group__P2P.html#gadee9ffd40892410c24336c1cd16b8f5a", null ],
    [ "registerPSendCADCallback", "da/d90/group__P2P.html#ga885de1a1e3618cc9dbf953b7ecedcd81", null ]
];