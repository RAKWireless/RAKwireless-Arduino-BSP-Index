var group__Serial =
[
    [ "HardwareSerial::begin", "dc/dc6/group__Serial.html#gaa667be774996900a314fcaae87e2b216", null ],
    [ "HardwareSerial::end", "dc/dc6/group__Serial.html#ga081b5c662ecee58405a543518f699d31", null ],
    [ "HardwareSerial::lock", "dc/dc6/group__Serial.html#ga47c702da390e8b0657539777f4fff56b", null ],
    [ "HardwareSerial::password", "dc/dc6/group__Serial.html#ga8dae286d1dcb4f3fdda25fb5ff3049f8", null ],
    [ "HardwareSerial::write", "dc/dc6/group__Serial.html#ga6ee174e74a6d460c4327c42f74ddc62b", null ],
    [ "HardwareSerial::available", "dc/dc6/group__Serial.html#gaeec8f4dbef97221a6041d6cdc6e9b716", null ],
    [ "HardwareSerial::read", "dc/dc6/group__Serial.html#gaead319e2866cf90d56c10f2ed39a4396", null ],
    [ "HardwareSerial::peek", "dc/dc6/group__Serial.html#ga65e3a688fcd31f2f486d3af02c400d8f", null ],
    [ "HardwareSerial::flush", "dc/dc6/group__Serial.html#ga0a4efd3d0f68d057f23eb5dfcd16c17c", null ],
    [ "HardwareSerial::getBaudrate", "dc/dc6/group__Serial.html#ga770bdbe5a289417c47088f04773bdb07", null ],
    [ "Print::print", "dc/dc6/group__Serial.html#ga447df1d390c7dc8af70f7e684963b212", null ],
    [ "Print::println", "dc/dc6/group__Serial.html#ga058fbcd23e761e3d2fbe06bb1a07b737", null ],
    [ "Print::printf", "dc/dc6/group__Serial.html#ga797e66b90cabc46d1921fbd35cb0bcea", null ],
    [ "Stream::setTimeout", "dc/dc6/group__Serial.html#ga76c7d6530b9cb17f6663a64aea84b61e", null ],
    [ "Stream::getTimeout", "dc/dc6/group__Serial.html#ga3706a766b0c864251f126fceda9913e1", null ],
    [ "Stream::readBytes", "dc/dc6/group__Serial.html#gada0b9486ea1fe7b8d4aab8f04f5607ee", null ],
    [ "Stream::readBytesUntil", "dc/dc6/group__Serial.html#ga9aa68dc2abab64ceafe8d8745b728af2", null ],
    [ "Stream::readString", "dc/dc6/group__Serial.html#gab1b0d4ef00718d18fe34d35dd1e26c66", null ],
    [ "Stream::readStringUntil", "dc/dc6/group__Serial.html#gac1f2b6e32ae2e321ad98c16482edf96a", null ]
];