var group__BLE__Setting =
[
    [ "mac", "da/ded/group__BLE__MAC.html", "da/ded/group__BLE__MAC" ],
    [ "txPower", "d3/d32/classRAKBleSettings_1_1txPower.html", [
      [ "set", "d3/d32/classRAKBleSettings_1_1txPower.html#a43e45450f3285b557181339988b31a23", null ],
      [ "get", "d3/d32/classRAKBleSettings_1_1txPower.html#a85e13862ef4c68f728f9331782da1ae9", null ]
    ] ],
    [ "advertiseInterval", "dd/d8c/classRAKBleSettings_1_1advertiseInterval.html", [
      [ "set", "dd/d8c/classRAKBleSettings_1_1advertiseInterval.html#a1bbde0def4aaf6ead3c2e2de99a34174", null ],
      [ "get", "dd/d8c/classRAKBleSettings_1_1advertiseInterval.html#a778335fa79020bb947b8730d3cd6fa4b", null ]
    ] ],
    [ "broadcastName", "d6/d5c/classRAKBleSettings_1_1broadcastName.html", [
      [ "set", "d6/d5c/classRAKBleSettings_1_1broadcastName.html#af942a5f042b513fe868a448c3132fc8f", null ],
      [ "get", "d6/d5c/classRAKBleSettings_1_1broadcastName.html#ab403dbff74ba3980715600169363f4ab", null ]
    ] ],
    [ "RAKBleAdvertise", "dd/d78/classRAKBleAdvertise.html", [
      [ "start", "dd/d78/classRAKBleAdvertise.html#a4b83f00d8d167a412b912d6c13c564b3", null ],
      [ "stop", "dd/d78/classRAKBleAdvertise.html#a68a350717fe6bf9012843e7c977d87b2", null ],
      [ "status", "dd/d78/classRAKBleAdvertise.html#aa69d81fb082f8d29a6af3faa554af4a6", null ]
    ] ],
    [ "blemode", "d7/dd2/group__BLE__Setting.html#gacc56838ba6df5c6a1d83cd758c6a35d9", null ]
];