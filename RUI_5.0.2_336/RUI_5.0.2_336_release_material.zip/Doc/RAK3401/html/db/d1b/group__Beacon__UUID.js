var group__Beacon__UUID =
[
    [ "RAKBleBeacon::iBeacon::iBeaconUuid::set", "db/d1b/group__Beacon__UUID.html#ga85c32351d59c4095b4861f3ad7e37955", null ]
];