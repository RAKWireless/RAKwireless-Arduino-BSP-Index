var group__RUI__Ble__Data__Type =
[
    [ "RAK_BLE_SERVICE_MODE", "d6/de0/group__RUI__Ble__Data__Type.html#gae95784100a17f40e7497eec48cfa2486", [
      [ "RAK_BLE_UART_MODE", "d6/de0/group__RUI__Ble__Data__Type.html#ggae95784100a17f40e7497eec48cfa2486a2a8bc094e34c7e291df26632122764e4", null ],
      [ "RAK_BLE_BEACON_MODE", "d6/de0/group__RUI__Ble__Data__Type.html#ggae95784100a17f40e7497eec48cfa2486aadb0ab2d25e488d0648144c61cca5114", null ]
    ] ],
    [ "RAK_CHARS_SECURITY_REQ", "d6/de0/group__RUI__Ble__Data__Type.html#ga9065ab7e94d0d8ccddae7319efd8dbe9", [
      [ "RAK_SET_OPEN", "d6/de0/group__RUI__Ble__Data__Type.html#gga9065ab7e94d0d8ccddae7319efd8dbe9adfebaa76b5f1be5a40dffa7aa918a39d", null ],
      [ "RAK_SET_ENC_NO_MITM", "d6/de0/group__RUI__Ble__Data__Type.html#gga9065ab7e94d0d8ccddae7319efd8dbe9ac89de4f7408b97c39e61cdb50a8d45e4", null ],
      [ "RAK_SET_ENC_WITH_MITM", "d6/de0/group__RUI__Ble__Data__Type.html#gga9065ab7e94d0d8ccddae7319efd8dbe9a23280af7d94c1721eb68d58f359c7d10", null ]
    ] ],
    [ "RAK_CHARS_PROPERTIES", "d6/de0/group__RUI__Ble__Data__Type.html#ga8edbfbff34e38fc8fa6996c3b3b8d72e", [
      [ "RAK_CHR_PROPS_READ", "d6/de0/group__RUI__Ble__Data__Type.html#gga8edbfbff34e38fc8fa6996c3b3b8d72eaf4553c2e8065eb7f7af12e34d7b5e8de", null ],
      [ "RAK_CHR_PROPS_NOTIFY", "d6/de0/group__RUI__Ble__Data__Type.html#gga8edbfbff34e38fc8fa6996c3b3b8d72ea988bd4fc571d46d2c4cd9fdeb12d96b4", null ]
    ] ]
];