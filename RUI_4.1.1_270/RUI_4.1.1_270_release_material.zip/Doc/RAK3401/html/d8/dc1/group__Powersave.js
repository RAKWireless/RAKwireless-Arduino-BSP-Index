var group__Powersave =
[
    [ "lpm", "d0/d00/classlpm.html", [
      [ "get", "d0/d00/classlpm.html#a86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "d0/d00/classlpm.html#ac3bbc06f12ee4803c554efae5bc32d0b", null ]
    ] ],
    [ "cpu", "d8/dc1/group__Powersave.html#gaac912606f26a982a46ef291e9b838c69", null ],
    [ "registerWakeupCallback", "d8/dc1/group__Powersave.html#ga60afe66af873c810ec0ff729ae8854ad", null ],
    [ "all", "d8/dc1/group__Powersave.html#gaea748bf0ce8d23588f91bb752e6ae93d", null ],
    [ "setup", "d8/dc1/group__Powersave.html#ga9e1c63bdeb8b2f70dceebb03a757acbf", null ]
];