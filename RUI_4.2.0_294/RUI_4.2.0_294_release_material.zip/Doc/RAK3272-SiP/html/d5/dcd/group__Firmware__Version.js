var group__Firmware__Version =
[
    [ "get", "d5/dcd/group__Firmware__Version.html#gac5f5202af3bb4156a22175cb76becb91", null ],
    [ "set", "d5/dcd/group__Firmware__Version.html#gaa7b03a182081ec7a7251bf4f7a3c127b", null ]
];