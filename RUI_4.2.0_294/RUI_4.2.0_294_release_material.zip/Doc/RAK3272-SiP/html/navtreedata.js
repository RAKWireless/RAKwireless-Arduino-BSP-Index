var NAVTREE =
[
  [ "RUI3 (RAK Unified Interface 3)  - RAK3172-SiP", "index.html", [
    [ "AT Command Manual", "df/db6/ATCMD.html", [
      [ "Bootloader Command", "df/db6/ATCMD.html#ATCMD_bootloader", [
        [ "AT+VER: Version of the Bootloader (bootloader only)", "df/db6/ATCMD.html#ATCMD_bootloader_1", null ],
        [ "AT+VERSION: Version of the Bootloader (bootloader only)", "df/db6/ATCMD.html#ATCMD_bootloader_2", null ],
        [ "AT+BOOTSTATUS: the status of the bootloader (bootloader only)", "df/db6/ATCMD.html#ATCMD_bootloader_3", null ],
        [ "AT+RUN: leaving boot mode (bootloader only)", "df/db6/ATCMD.html#ATCMD_bootloader_4", null ],
        [ "AT+RESET: device reset (bootloader only)", "df/db6/ATCMD.html#ATCMD_bootloader_5", null ],
        [ "AT+UPDATE: Y-modem receiving process (stm32 bootloader only)", "df/db6/ATCMD.html#ATCMD_bootloader_6", null ]
      ] ],
      [ "LoRa Certification", "df/db6/ATCMD.html#ATCMD_cert", [
        [ "AT+TRSSI: RF RSSI tone test", "df/db6/ATCMD.html#ATCMD_cert_1", null ],
        [ "AT+TTONE: RF tone test", "df/db6/ATCMD.html#ATCMD_cert_2", null ],
        [ "AT+TTX: RF TX LoRa test", "df/db6/ATCMD.html#ATCMD_cert_3", null ],
        [ "AT+TRX: RF RX LoRa test", "df/db6/ATCMD.html#ATCMD_cert_4", null ],
        [ "AT+TCONF: Configure LoRa RF test", "df/db6/ATCMD.html#ATCMD_cert_5", null ],
        [ "AT+TTH: RF Tx hopping test", "df/db6/ATCMD.html#ATCMD_cert_6", null ],
        [ "AT+TOFF: Stop ongoing radio frequency test", "df/db6/ATCMD.html#ATCMD_cert_7", null ],
        [ "AT+CERTIF: LoraWAN certification mode", "df/db6/ATCMD.html#ATCMD_cert_8", null ],
        [ "AT+CW: Send continuous wave", "df/db6/ATCMD.html#ATCMD_cert_9", null ],
        [ "AT+TRTH: RF Tx hopping test in random sequence", "df/db6/ATCMD.html#ATCMD_cert_10", null ]
      ] ],
      [ "LoRaWAN Class B", "df/db6/ATCMD.html#ATCMD_class_b_mode", [
        [ "AT+PGSLOT", "df/db6/ATCMD.html#ATCMD_class_b_mode_1", null ],
        [ "AT+BFREQ", "df/db6/ATCMD.html#ATCMD_class_b_mode_2", null ],
        [ "AT+BTIME", "df/db6/ATCMD.html#ATCMD_class_b_mode_3", null ],
        [ "AT+BGW", "df/db6/ATCMD.html#ATCMD_class_b_mode_4", null ],
        [ "AT+LTIME", "df/db6/ATCMD.html#ATCMD_class_b_mode_5", null ]
      ] ],
      [ "General Command", "df/db6/ATCMD.html#ATCMD_general", [
        [ "AT: Attention", "df/db6/ATCMD.html#ATCMD_general_1", null ],
        [ "AT?: Short Help", "df/db6/ATCMD.html#ATCMD_general_2", null ],
        [ "ATZ: MCU Reset", "df/db6/ATCMD.html#ATCMD_general_3", null ],
        [ "ATR: Restore Default Parameters", "df/db6/ATCMD.html#ATCMD_general_4", null ],
        [ "AT+BOOT: Bootloader Mode", "df/db6/ATCMD.html#ATCMD_general_5", null ],
        [ "ATE: Command Echo", "df/db6/ATCMD.html#ATCMD_general_6", null ],
        [ "AT+SN: get the serial number of the device", "df/db6/ATCMD.html#ATCMD_general_7", null ],
        [ "AT+BAT: Battery Level", "df/db6/ATCMD.html#ATCMD_general_8", null ],
        [ "AT+BUILDTIME: Build Time of the Firmware", "df/db6/ATCMD.html#ATCMD_general_9", null ],
        [ "AT+REPOINFO: Repository Information", "df/db6/ATCMD.html#ATCMD_general_10", null ],
        [ "AT+VER: Version of the Firmware", "df/db6/ATCMD.html#ATCMD_general_11", null ],
        [ "AT+CLIVER: Version of the AT Command", "df/db6/ATCMD.html#ATCMD_general_12", null ],
        [ "AT+APIVER: Version of the RUI API", "df/db6/ATCMD.html#ATCMD_general_13", null ],
        [ "AT+HWMODEL: Hardware Model", "df/db6/ATCMD.html#ATCMD_general_14", null ],
        [ "AT+HWID: Hardware ID", "df/db6/ATCMD.html#ATCMD_general_15", null ],
        [ "AT+ALIAS: Alias Name of the Device", "df/db6/ATCMD.html#ATCMD_general_16", null ],
        [ "AT+SYSV: get the System Voltage", "df/db6/ATCMD.html#ATCMD_general_17", null ],
        [ "AT+BLEMAC: get or set the BLE Mac address", "df/db6/ATCMD.html#ATCMD_general_18", null ],
        [ "AT+BOOTVER: get the version of RUI Bootloader", "df/db6/ATCMD.html#ATCMD_general_19", null ]
      ] ],
      [ "LoRaWAN Information", "df/db6/ATCMD.html#ATCMD_info", [
        [ "AT+RSSI: RSSI on reception", "df/db6/ATCMD.html#ATCMD_info_1", null ],
        [ "AT+ARSSI: access all open channel rssi", "df/db6/ATCMD.html#ATCMD_info_2", null ],
        [ "AT+SNR: signal noise ratio", "df/db6/ATCMD.html#ATCMD_info_3", null ]
      ] ],
      [ "LoRaWAN Joining and Sending", "df/db6/ATCMD.html#ATCMD_join_send", [
        [ "AT+CFM: confirm mode", "df/db6/ATCMD.html#ATCMD_join_send_1", null ],
        [ "AT+CFS: confirm status", "df/db6/ATCMD.html#ATCMD_join_send_2", null ],
        [ "AT+JOIN: AT+JOIN: join LoRa network", "df/db6/ATCMD.html#ATCMD_join_send_3", null ],
        [ "AT+NJM: LoRa network join mode", "df/db6/ATCMD.html#ATCMD_join_send_4", null ],
        [ "AT+NJS: LoRa network join status", "df/db6/ATCMD.html#ATCMD_join_send_5", null ],
        [ "AT+RECV: last received data", "df/db6/ATCMD.html#ATCMD_join_send_6", null ],
        [ "AT+SEND: send data", "df/db6/ATCMD.html#ATCMD_join_send_7", null ],
        [ "AT+LPSEND: This command provides the way to send long packet data", "df/db6/ATCMD.html#ATCMD_join_send_8", null ],
        [ "AT+RETY: set the number of retransmission of confirm packet data", "df/db6/ATCMD.html#ATCMD_join_send_9", null ]
      ] ],
      [ "LoRaWAN Keys and IDs", "df/db6/ATCMD.html#ATCMD_key_id", [
        [ "AT+APPEUI: application identifier", "df/db6/ATCMD.html#ATCMD_key_id_1", null ],
        [ "AT+APPKEY: application key", "df/db6/ATCMD.html#ATCMD_key_id_2", null ],
        [ "AT+APPSKEY: application session key", "df/db6/ATCMD.html#ATCMD_key_id_3", null ],
        [ "AT+DEVADDR: device address", "df/db6/ATCMD.html#ATCMD_key_id_4", null ],
        [ "AT+DEVEUI: device EUI", "df/db6/ATCMD.html#ATCMD_key_id_5", null ],
        [ "AT+NETID: network identifier (NetID)", "df/db6/ATCMD.html#ATCMD_key_id_6", null ],
        [ "AT+NWKSKEY: network session key", "df/db6/ATCMD.html#ATCMD_key_id_7", null ],
        [ "AT+MCROOTKEY: mc root key", "df/db6/ATCMD.html#ATCMD_key_id_8", null ]
      ] ],
      [ "LoRaWAN Multicast Group", "df/db6/ATCMD.html#ATCMD_multicast", [
        [ "AT+ADDMULC: Add a new multicast group", "df/db6/ATCMD.html#ATCMD_multicast_1", null ],
        [ "AT+RMVMULC: Remove a multicast group", "df/db6/ATCMD.html#ATCMD_multicast_2", null ],
        [ "AT+LSTMULC: multicast group list", "df/db6/ATCMD.html#ATCMD_multicast_3", null ]
      ] ],
      [ "LoRaWAN Network Management", "df/db6/ATCMD.html#ATCMD_nwk_mng", [
        [ "AT+ADR: adaptive rate", "df/db6/ATCMD.html#ATCMD_nwk_mng_1", null ],
        [ "AT+CLASS: LoRa class", "df/db6/ATCMD.html#ATCMD_nwk_mng_2", null ],
        [ "AT+DCS: duty cycle settings", "df/db6/ATCMD.html#ATCMD_nwk_mng_3", null ],
        [ "AT+DR: data rate", "df/db6/ATCMD.html#ATCMD_nwk_mng_4", null ],
        [ "AT+JN1DL: join delay on RX window 1", "df/db6/ATCMD.html#ATCMD_nwk_mng_5", null ],
        [ "AT+JN2DL: join delay on RX window 2", "df/db6/ATCMD.html#ATCMD_nwk_mng_6", null ],
        [ "AT+PNM: public network mode", "df/db6/ATCMD.html#ATCMD_nwk_mng_7", null ],
        [ "AT+RX1DL: delay of the received window 1", "df/db6/ATCMD.html#ATCMD_nwk_mng_8", null ],
        [ "AT+RX2DL: delay of the received window 2", "df/db6/ATCMD.html#ATCMD_nwk_mng_9", null ],
        [ "AT+RX2DR: data rate of the received window 2", "df/db6/ATCMD.html#ATCMD_nwk_mng_10", null ],
        [ "AT+RX2FQ: frequency of the received window 2", "df/db6/ATCMD.html#ATCMD_nwk_mng_11", null ],
        [ "AT+TXP: transmit power", "df/db6/ATCMD.html#ATCMD_nwk_mng_12", null ],
        [ "AT+LINKCHECK: link check", "df/db6/ATCMD.html#ATCMD_nwk_mng_13", null ],
        [ "AT+TIMEREQ: time request", "df/db6/ATCMD.html#ATCMD_nwk_mng_14", null ],
        [ "AT+LBT: LoRaWAN LBT", "df/db6/ATCMD.html#ATCMD_nwk_mng_15", null ],
        [ "AT+LBTRSSI: LoRaWAN LBT RSSI", "df/db6/ATCMD.html#ATCMD_nwk_mng_16", null ],
        [ "AT+LBTSCANTIME: LoRaWAN LBT scantime", "df/db6/ATCMD.html#ATCMD_nwk_mng_17", null ]
      ] ],
      [ "LoRaWAN P2P", "df/db6/ATCMD.html#ATCMD_p2p", [
        [ "AT+NWM: network working mode", "df/db6/ATCMD.html#ATCMD_p2p_1", null ],
        [ "AT+PFREQ: frequency", "df/db6/ATCMD.html#ATCMD_p2p_2", null ],
        [ "AT+PSF: spreading factor", "df/db6/ATCMD.html#ATCMD_p2p_3", null ],
        [ "AT+PBW: bandwidth", "df/db6/ATCMD.html#ATCMD_p2p_4", null ],
        [ "AT+PCR: coding rate", "df/db6/ATCMD.html#ATCMD_p2p_5", null ],
        [ "AT+PPL: the length of preamble", "df/db6/ATCMD.html#ATCMD_p2p_6", null ],
        [ "AT+PTP: tx power", "df/db6/ATCMD.html#ATCMD_p2p_7", null ],
        [ "AT+PSEND: send data", "df/db6/ATCMD.html#ATCMD_p2p_8", null ],
        [ "AT+PRECV: receive data", "df/db6/ATCMD.html#ATCMD_p2p_9", null ],
        [ "AT+PCRYPT: the crypt status", "df/db6/ATCMD.html#ATCMD_p2p_10", null ],
        [ "AT+PKEY: the encryption and decryption key", "df/db6/ATCMD.html#ATCMD_p2p_11", null ],
        [ "AT+P2P: all P2P parameters", "df/db6/ATCMD.html#ATCMD_p2p_12", null ],
        [ "AT+PBR: get or set the P2P FSK modem bitrate (600b/s-300000b/s)", "df/db6/ATCMD.html#ATCMD_p2p_13", null ],
        [ "AT+PFDEV: get or set the P2P FSK modem frequency deviation", "df/db6/ATCMD.html#ATCMD_p2p_14", null ],
        [ "AT+IQINVER: IQ inversion in p2p mode", "df/db6/ATCMD.html#ATCMD_p2p_15", null ],
        [ "AT+SYNCWORD: P2P syncword (0x0000 - 0xffff) in p2p mode", "df/db6/ATCMD.html#ATCMD_p2p_16", null ],
        [ "AT+RFFREQUENCY: frequency in p2p mode", "df/db6/ATCMD.html#ATCMD_p2p_17", null ],
        [ "AT+TXOUTPUTPOWER: P2P Tx Power(5-22)", "df/db6/ATCMD.html#ATCMD_p2p_18", null ],
        [ "AT+BANDWIDTH:P2P Bandwidth", "df/db6/ATCMD.html#ATCMD_p2p_19", null ],
        [ "AT+SPREADINGFACTOR: P2P Spreading Factor (5-12)", "df/db6/ATCMD.html#ATCMD_p2p_20", null ],
        [ "AT+SPREADINGFACTOR: P2P coding rate", "df/db6/ATCMD.html#ATCMD_p2p_21", null ],
        [ "AT+PREAMBLELENGTH: P2P Preamble Length (5-65535)", "df/db6/ATCMD.html#ATCMD_p2p_22", null ],
        [ "AT+SYMBOLTIMEOUT: P2P symbolTimeout (0-248)", "df/db6/ATCMD.html#ATCMD_p2p_23", null ],
        [ "AT+FIXLENGTHPAYLOAD: P2P fix length payload on/off ( 1 = on, 0 = off)", "df/db6/ATCMD.html#ATCMD_p2p_24", null ],
        [ "AT+ENCRY: P2P encryption status", "df/db6/ATCMD.html#ATCMD_p2p_25", null ],
        [ "AT+ENCKEY: P2P encryption key", "df/db6/ATCMD.html#ATCMD_p2p_26", null ],
        [ "AT+CRYPIV: P2P encryption IV", "df/db6/ATCMD.html#ATCMD_p2p_27", null ],
        [ "AT+CAD: P2P Channel Activity Detection", "df/db6/ATCMD.html#ATCMD_p2p_28", null ]
      ] ],
      [ "Serial Port Command", "df/db6/ATCMD.html#ATCMD_serial_port", [
        [ "AT+LOCK: Lock the AT command serial port", "df/db6/ATCMD.html#ATCMD_serial_port_1", null ],
        [ "AT+PWORD: the password for locking the AT command serial port", "df/db6/ATCMD.html#ATCMD_serial_port_2", null ],
        [ "AT+BAUD: the serial port baudrate", "df/db6/ATCMD.html#ATCMD_serial_port_3", null ],
        [ "AT+ATM: AT command mode", "df/db6/ATCMD.html#ATCMD_serial_port_4", null ],
        [ "AT+APM: API mode", "df/db6/ATCMD.html#ATCMD_serial_port_5", null ]
      ] ],
      [ "Sleep Command", "df/db6/ATCMD.html#ATCMD_sleep", [
        [ "AT+SLEEP: sleep mode", "df/db6/ATCMD.html#ATCMD_sleep_1", null ],
        [ "AT+LPM: low power mode", "df/db6/ATCMD.html#ATCMD_sleep_2", null ],
        [ "AT+LPMLVL: the sleep level for low power mode", "df/db6/ATCMD.html#ATCMD_sleep_3", null ]
      ] ],
      [ "Supplementary Command", "df/db6/ATCMD.html#ATCMD_supplement", [
        [ "AT+MASK: Access the channel mask to close or open the channel.", "df/db6/ATCMD.html#ATCMD_supplement_1", null ],
        [ "AT+BAND: active region", "df/db6/ATCMD.html#ATCMD_supplement_2", null ],
        [ "AT+CHE: get or set eight channels mode (only for US915 AU915 CN470)", "df/db6/ATCMD.html#ATCMD_supplement_3", null ],
        [ "AT+CHS: get or set single channels mode (only for US915 AU915 CN470)", "df/db6/ATCMD.html#ATCMD_supplement_4", null ]
      ] ]
    ] ],
    [ "RUI3 API", "modules.html", "modules" ]
  ] ]
];

var NAVTREEINDEX =
[
"d0/d00/classlpm.html",
"da/dc1/group__RUI__Arduino__Data__Type.html#ggab9780fbfa8e1586d992b12efeb7721d1a4dadeca9c742154ae826bb9fb1fcad38",
"df/db6/ATCMD.html#ATCMD_key_id_4"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';