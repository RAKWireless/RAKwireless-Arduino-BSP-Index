var searchData=
[
  ['kilometers',['kilometers',['../d1/d54/structTinyGPSAltitude.html#a1ee8883cb51c3e699d7edefa13683bb9',1,'TinyGPSAltitude']]],
  ['kmph',['kmph',['../dc/dd0/structTinyGPSSpeed.html#a75f40e3d9b17263bc48cdb7981b5e484',1,'TinyGPSSpeed']]],
  ['knots',['knots',['../dc/dd0/structTinyGPSSpeed.html#a0034c4dae03c339a112c77761753744a',1,'TinyGPSSpeed']]]
];
