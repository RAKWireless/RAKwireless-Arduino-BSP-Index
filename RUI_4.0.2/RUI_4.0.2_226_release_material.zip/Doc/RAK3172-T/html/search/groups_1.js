var searchData=
[
  ['bit_20and_20byte',['Bit and Byte',['../d1/d39/group__Bit__and__Byte.html',1,'']]],
  ['battery',['Battery',['../d2/ddb/group__System__Battery.html',1,'']]]
];
