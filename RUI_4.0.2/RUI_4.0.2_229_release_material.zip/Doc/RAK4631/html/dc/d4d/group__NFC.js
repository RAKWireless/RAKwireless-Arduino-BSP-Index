var group__NFC =
[
    [ "init", "dc/d4d/group__NFC.html#ga39d312b7e6210a0953ed0822ed026761", null ],
    [ "send", "dc/d4d/group__NFC.html#ga2dffa486c48aef2ee5c00cd285b8c301", null ],
    [ "close", "dc/d4d/group__NFC.html#ga5ae591df94fc66ccb85cbb6565368bca", null ]
];