var group__BLE__func =
[
    [ "RAKBle::stop", "d8/d7d/group__BLE__func.html#gaacf6bf8e121fea8b0a92d7197b73fe27", null ],
    [ "RAKBle::registerCallback", "d8/d7d/group__BLE__func.html#ga1b54d27c21f5a451440be21c7cd032e9", null ]
];