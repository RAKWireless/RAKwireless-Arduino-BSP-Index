var group__Customize__Service =
[
    [ "RAKBleService", "d4/df1/classRAKBleService.html", [
      [ "RAKBleService", "d4/df1/classRAKBleService.html#a8142424564748326bddb0a9979031ed5", null ],
      [ "begin", "d4/df1/classRAKBleService.html#ab0bdf5cca484fb2ba637c39384b27fb2", null ]
    ] ],
    [ "RAKBleCharacteristic", "d9/dcd/classRAKBleCharacteristic.html", [
      [ "RAKBleCharacteristic", "d9/dcd/classRAKBleCharacteristic.html#aee3e11404df6a39082e29c0fa9f711ac", null ],
      [ "setProperties", "d9/dcd/classRAKBleCharacteristic.html#a5694a6673a5215ae0454649f7e2132a1", null ],
      [ "setPermission", "d9/dcd/classRAKBleCharacteristic.html#ac499c831063912c063ddd8d5fb254d05", null ],
      [ "setFixedLen", "d9/dcd/classRAKBleCharacteristic.html#aab6eb13c6a5756627b77e214ca8c706e", null ],
      [ "begin", "d9/dcd/classRAKBleCharacteristic.html#ab0bdf5cca484fb2ba637c39384b27fb2", null ],
      [ "notify", "d9/dcd/classRAKBleCharacteristic.html#a298c459939af047750a32a9433572473", null ],
      [ "write", "d9/dcd/classRAKBleCharacteristic.html#ab3ada3f52da53220d0ba4ca019a38c64", null ],
      [ "notifyEnabled", "d9/dcd/classRAKBleCharacteristic.html#a1e8ac7971c6528544fb4b8e6b3c48058", null ],
      [ "setCccdWriteCallback", "d9/dcd/classRAKBleCharacteristic.html#ad9c822d838516789403c9c013ece5e31", null ],
      [ "setWriteCallback", "d9/dcd/classRAKBleCharacteristic.html#ae06da5186957553a0ebca35685f7eb43", null ]
    ] ],
    [ "RAKBleCustom", "d2/d29/classRAKBleCustom.html", [
      [ "init", "d2/d29/classRAKBleCustom.html#a02fd73d861ef2e4aabb38c0c9ff82947", null ],
      [ "start", "d2/d29/classRAKBleCustom.html#a60de64d75454385b23995437f1d72669", null ]
    ] ]
];