var group__System__Alias =
[
    [ "RAKSystem::alias::set", "de/d55/group__System__Alias.html#ga2272e42caeb434af9ee148ea8ff4e328", null ],
    [ "RAKSystem::alias::get", "de/d55/group__System__Alias.html#ga5f6d46f9e2d35565e8146b85d0b693f7", null ]
];