var group__Wire =
[
    [ "TwoWire::begin", "d7/dae/group__Wire.html#gaad78931e44ce43c9b9c460dba7c9bbb7", null ],
    [ "TwoWire::end", "d7/dae/group__Wire.html#ga081b5c662ecee58405a543518f699d31", null ],
    [ "TwoWire::setClock", "d7/dae/group__Wire.html#ga11fa1c20ba83f4dd88c5c35873a8893b", null ],
    [ "TwoWire::beginTransmission", "d7/dae/group__Wire.html#gafce19cad47cff1b3acd43dafd62bd3a8", null ],
    [ "TwoWire::endTransmission", "d7/dae/group__Wire.html#ga1ab0ab39d52808aeb94d7fffa96620de", null ],
    [ "TwoWire::requestFrom", "d7/dae/group__Wire.html#gaceb9bf530d9a28c4d73a298e12b3da53", null ],
    [ "TwoWire::write", "d7/dae/group__Wire.html#ga5f985ca872c6ce5fb8fe126cf9a0a01f", null ],
    [ "TwoWire::available", "d7/dae/group__Wire.html#gaeec8f4dbef97221a6041d6cdc6e9b716", null ],
    [ "TwoWire::read", "d7/dae/group__Wire.html#gaead319e2866cf90d56c10f2ed39a4396", null ]
];