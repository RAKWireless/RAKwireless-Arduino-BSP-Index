var group__RUI__Lorawan__Data__Type =
[
    [ "RAK_LORA_McSession", "df/d1f/structRAK__LORA__McSession.html", [
      [ "McDevclass", "df/d1f/structRAK__LORA__McSession.html#a8880c6395ab3e45bfdb3ff4153764e3e", null ],
      [ "McAddress", "df/d1f/structRAK__LORA__McSession.html#a91d59aabc7b3cf1524cff9dfa3ff0f4f", null ],
      [ "McAppSKey", "df/d1f/structRAK__LORA__McSession.html#a3e5410de49004f5bf990b10e4902e00f", null ],
      [ "McNwkSKey", "df/d1f/structRAK__LORA__McSession.html#a3e42e3e105838ca7d1cf6cadbab6ac0b", null ],
      [ "McFrequency", "df/d1f/structRAK__LORA__McSession.html#a5df76ee656aad7c54e40fbd9d572d285", null ],
      [ "McDatarate", "df/d1f/structRAK__LORA__McSession.html#a76c6c14c005e0155001047886ff5d14a", null ],
      [ "McPeriodicity", "df/d1f/structRAK__LORA__McSession.html#aee13d3d2aba615042dd92bd1f43cde37", null ],
      [ "McGroupID", "df/d1f/structRAK__LORA__McSession.html#a1fbcc23862f1d55f67519f6ad7a8cbb7", null ],
      [ "entry", "df/d1f/structRAK__LORA__McSession.html#adbdb38b7f14c384804844026547a276e", null ]
    ] ],
    [ "RAK_LORA_chan_rssi", "d1/d81/structRAK__LORA__chan__rssi.html", [
      [ "chan", "d1/d81/structRAK__LORA__chan__rssi.html#afb67f3e4e204785118073a96b76614d6", null ],
      [ "mask", "d1/d81/structRAK__LORA__chan__rssi.html#a7fd850d4bb04f7410e8e2abf5f349348", null ],
      [ "rssi", "d1/d81/structRAK__LORA__chan__rssi.html#a3b962e67ba74725bd60ca3c29f785abe", null ]
    ] ],
    [ "RAKLoRaMacEventInfoStatus_t", "de/d56/group__RUI__Lorawan__Data__Type.html#ga7c9f18e5d84b31eb120215ede3a57df1", null ],
    [ "RAK_LORA_BAND", "de/d56/group__RUI__Lorawan__Data__Type.html#ga4b8c367e751e52fdb9bf0daeb01f501b", [
      [ "RAK_REGION_EU433", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba1fbeaac26403fc93d4ca51dbae407a72", null ],
      [ "RAK_REGION_CN470", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba62d066d2c1686b8df226cd43adec850f", null ],
      [ "RAK_REGION_RU864", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba193a6f81065ed5059d31966f717625d6", null ],
      [ "RAK_REGION_IN865", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501baa55ac5d51e0d00d86d4ad6f35d72534f", null ],
      [ "RAK_REGION_EU868", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501baf251060a5ebbd49acdfa9ee459c6ab16", null ],
      [ "RAK_REGION_US915", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501baf51e8c3353b5773cd81ffa31ca8de950", null ],
      [ "RAK_REGION_AU915", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba9d01575b3d4697a4ba78f9f13d04824e", null ],
      [ "RAK_REGION_KR920", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501bac221eb115d632600c809ea947d5d24eb", null ],
      [ "RAK_REGION_AS923", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba09f40ae957af953e8a57002d9e6acbb6", null ],
      [ "RAK_REGION_AS923_2", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba240eceec7e7ca12ae5519c4bab1eb195", null ],
      [ "RAK_REGION_AS923_3", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba0941ee7356d71245ae712bd22b095c83", null ],
      [ "RAK_REGION_AS923_4", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501ba42a4150d94f2cf9ec62ca7432f07b36a", null ],
      [ "RAK_REGION_LA915", "de/d56/group__RUI__Lorawan__Data__Type.html#gga4b8c367e751e52fdb9bf0daeb01f501baa722a0442c2d43bf6ad210e6ed471c6e", null ]
    ] ],
    [ "RAK_LORA_JOIN_MODE", "de/d56/group__RUI__Lorawan__Data__Type.html#gae0315aed26d67c63ae036a2b8f6a58ab", [
      [ "RAK_LORA_ABP", "de/d56/group__RUI__Lorawan__Data__Type.html#ggae0315aed26d67c63ae036a2b8f6a58abac955cb4a6f6e20996e3335f33ab6e88a", null ],
      [ "RAK_LORA_OTAA", "de/d56/group__RUI__Lorawan__Data__Type.html#ggae0315aed26d67c63ae036a2b8f6a58aba561f1f24597f9b4b58c887b7594dc6ea", null ]
    ] ],
    [ "RAK_LORA_CONFIRM_MODE", "de/d56/group__RUI__Lorawan__Data__Type.html#ga8fde2d1fa94b843144063b2f56260d2d", [
      [ "RAK_LORA_NO_ACK", "de/d56/group__RUI__Lorawan__Data__Type.html#gga8fde2d1fa94b843144063b2f56260d2da67023bb91de2fe123df48ef47b71ae2c", null ],
      [ "RAK_LORA_ACK", "de/d56/group__RUI__Lorawan__Data__Type.html#gga8fde2d1fa94b843144063b2f56260d2dae26518a000ed7ae5371a190691b014f1", null ]
    ] ],
    [ "RAK_LORA_CLASS", "de/d56/group__RUI__Lorawan__Data__Type.html#gab23a5817dcc95b55ac49f9ed52b660fe", [
      [ "RAK_LORA_CLASS_A", "de/d56/group__RUI__Lorawan__Data__Type.html#ggab23a5817dcc95b55ac49f9ed52b660fea65004a128fd53f1742be4fcf6a7cf1df", null ],
      [ "RAK_LORA_CLASS_B", "de/d56/group__RUI__Lorawan__Data__Type.html#ggab23a5817dcc95b55ac49f9ed52b660fea701e64d10dd68f6dc8636bd2164fe2b2", null ],
      [ "RAK_LORA_CLASS_C", "de/d56/group__RUI__Lorawan__Data__Type.html#ggab23a5817dcc95b55ac49f9ed52b660fea20757f4cfcb9c4b21465301bc30032ac", null ]
    ] ],
    [ "RAKLoRaMacEventInfoStatus", "de/d56/group__RUI__Lorawan__Data__Type.html#ga53f1efae54b75e1f18dec7915d51698b", [
      [ "RAK_LORAMAC_STATUS_OK", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698badd796e307116e1bf02bfeb049a962e47", null ],
      [ "RAK_LORAMAC_STATUS_ERROR", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba41f9d09859f89f8aa8f76c71f8eb4824", null ],
      [ "RAK_LORAMAC_STATUS_TX_TIMEOUT", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba52c30dd888678a2b974cfbd4d5cd1222", null ],
      [ "RAK_LORAMAC_STATUS_RX1_TIMEOUT", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba8dff955e2757aaa744ea612459e9946c", null ],
      [ "RAK_LORAMAC_STATUS_RX2_TIMEOUT", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba76b51a1130c5239441382a51743c8d18", null ],
      [ "RAK_LORAMAC_STATUS_RX1_ERROR", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba619de482c592cec40ea31902a25a0380", null ],
      [ "RAK_LORAMAC_STATUS_RX2_ERROR", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba6c7d939b905c09c9aa3b06404bab87a4", null ],
      [ "RAK_LORAMAC_STATUS_JOIN_FAIL", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698baa261e7da5a641017a561ba00d720eea3", null ],
      [ "RAK_LORAMAC_STATUS_DOWNLINK_REPEATED", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698bae1dd65677cb18aa2dc7a68f8102e5b90", null ],
      [ "RAK_LORAMAC_STATUS_TX_DR_PAYLOAD_SIZE_ERROR", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba7e06cb151622c2d9459bee3d90f9d418", null ],
      [ "RAK_LORAMAC_STATUS_DOWNLINK_TOO_MANY_FRAMES_LOSS", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba2cc06e5658de74f75b8ec3e04b0b1dab", null ],
      [ "RAK_LORAMAC_STATUS_ADDRESS_FAIL", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba27b84ae0bbabed76a1d69d38fc3584e2", null ],
      [ "RAK_LORAMAC_STATUS_MIC_FAIL", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698bacb434cbbe90365e153a5a4ed16925def", null ],
      [ "RAK_LORAMAC_STATUS_MULTICAST_FAIL", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba51740bcd2e2f8c8a00176525a77a1ed8", null ],
      [ "RAK_LORAMAC_STATUS_BEACON_LOCKED", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698badf3f899f0ae4662efcafe9ae621b980e", null ],
      [ "RAK_LORAMAC_STATUS_BEACON_LOST", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698babe5246e1f615cc505c131455976352ff", null ],
      [ "RAK_LORAMAC_STATUS_BEACON_NOT_FOUND", "de/d56/group__RUI__Lorawan__Data__Type.html#gga53f1efae54b75e1f18dec7915d51698ba16c819ec8e4226b009d29e6a540fc76b", null ]
    ] ]
];