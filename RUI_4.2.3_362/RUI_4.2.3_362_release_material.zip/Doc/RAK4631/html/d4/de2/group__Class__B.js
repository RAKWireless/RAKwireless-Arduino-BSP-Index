var group__Class__B =
[
    [ "RAKLorawan::pgslot", "d3/d45/classRAKLorawan_1_1pgslot.html", [
      [ "get", "d3/d45/classRAKLorawan_1_1pgslot.html#a86f20d297fd329a71da133cf7ac32b9a", null ],
      [ "set", "d3/d45/classRAKLorawan_1_1pgslot.html#ac3bbc06f12ee4803c554efae5bc32d0b", null ]
    ] ],
    [ "RAKLorawan::bfreq", "d3/dc1/classRAKLorawan_1_1bfreq.html", [
      [ "get", "d3/dc1/classRAKLorawan_1_1bfreq.html#aa3bed7d127f9d539c63af5575136f6df", null ]
    ] ],
    [ "RAKLorawan::btime", "d5/def/classRAKLorawan_1_1btime.html", [
      [ "get", "d5/def/classRAKLorawan_1_1btime.html#aafbaa9527425920d5d8b4bebcc1b52f1", null ]
    ] ],
    [ "RAKLorawan::bgw", "dd/d8e/classRAKLorawan_1_1bgw.html", [
      [ "get", "dd/d8e/classRAKLorawan_1_1bgw.html#a9f65304a384b6eaf557414fb8d6cc323", null ]
    ] ],
    [ "RAKLorawan::ltime", "de/d0f/classRAKLorawan_1_1ltime.html", [
      [ "get", "de/d0f/classRAKLorawan_1_1ltime.html#a8691e1e6f2a6ebcab5ee45ba08622f0d", null ],
      [ "get", "de/d0f/classRAKLorawan_1_1ltime.html#a97fbb198e65dfedb8ecd979d9317dc26", null ]
    ] ]
];