var group__Beacon__Mode =
[
    [ "iBeacon", "dd/d4f/group__I__Beacon.html", "dd/d4f/group__I__Beacon" ]
];