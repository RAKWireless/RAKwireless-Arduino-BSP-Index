var searchData=
[
  ['valid_5fmark_5f1_0',['valid_mark_1',['../dd/db4/structs__lorawan__settings.html#a65aaa8dad02568c386816d582b1bcc6f',1,'s_lorawan_settings']]],
  ['valid_5fmark_5f2_1',['valid_mark_2',['../dd/db4/structs__lorawan__settings.html#a951d78ffc89710e64b5f66e6fa510eb9',1,'s_lorawan_settings']]],
  ['ver_2',['ver',['../d1/d0a/classRAKLorawan.html#a7d280c90c7e608c3f29ae792b8d2b9fb',1,'RAKLorawan']]],
  ['version_5fcode_3',['version_code',['../d0/d5e/structPRE__rui__cfg__t.html#aca83e4d586ea1ef5b6cf9b662adbc503',1,'PRE_rui_cfg_t']]]
];
