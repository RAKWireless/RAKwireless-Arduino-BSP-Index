var searchData=
[
  ['chars_5fproperties_0',['chars_properties',['../d6/d10/udrv__ble_8h.html#ad832e16569870d0b203963f079164e63',1,'udrv_ble.h']]],
  ['chars_5fsecurity_5freq_1',['chars_security_req',['../d6/d10/udrv__ble_8h.html#acd6ce786dee4378ddc3a23316ab99ca7',1,'udrv_ble.h']]]
];
