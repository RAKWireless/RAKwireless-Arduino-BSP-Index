var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz~",
  1: "_abcdefghijlmnpqrstuvw",
  2: "abcdfhilmnprstuw",
  3: "_abcdefghijklmnoprstuvwxyz~",
  4: "_abcdefghijlmnopqrstuvwxyz",
  5: "abcdefgilmprstuw",
  6: "_abcdeghilorstu",
  7: "abcdghiklmoprstu",
  8: "o",
  9: "_abcdefghilmoprstuvw",
  10: "abcdfijklmnoprstuw",
  11: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros",
  10: "Modules",
  11: "Pages"
};

