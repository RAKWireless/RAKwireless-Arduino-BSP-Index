var searchData=
[
  ['udrv_5fnfc_5ft4t_5fcallback_0',['udrv_nfc_t4t_callback',['../d5/d62/udrv__nfc_8h.html#af0890692f38c582d8f0cf571d67d7211',1,'udrv_nfc.h']]],
  ['udrv_5freturn_5fcode_1',['UDRV_RETURN_CODE',['../d1/dca/udrv__errno_8h.html#a9af5562c19f8c3c66eea10d373ae7d42',1,'udrv_errno.h']]],
  ['udrv_5ftask_5fhandler_2',['UDRV_TASK_HANDLER',['../d7/d4a/udrv__system_8h.html#ac3c5e0051404c70265d678343dcfc8c7',1,'udrv_system.h']]],
  ['uint_5ffarptr_5ft_3',['uint_farptr_t',['../d4/ddc/pgmspace_8h.html#a07beca64a84d7ba8ea8946ed0e58f367',1,'pgmspace.h']]]
];
