var group__Beacon__Minor =
[
    [ "RAKBleBeacon::iBeacon::iBeaconMinor::set", "d3/d76/group__Beacon__Minor.html#ga17254185f01fd7b8890ca7c957389858", null ]
];