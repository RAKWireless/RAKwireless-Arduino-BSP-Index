var group__Api__Mode =
[
    [ "send", "db/d0a/group__Api__Mode.html#gae160964523327729c4af17093c6f4c92", null ],
    [ "registerHandler", "db/d0a/group__Api__Mode.html#gaa6d0f3df612ea6f98160d85d04ea6f4e", null ],
    [ "deregisterHandler", "db/d0a/group__Api__Mode.html#ga3397b57459777981e5290b3537b09fed", null ]
];