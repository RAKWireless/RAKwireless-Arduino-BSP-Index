var searchData=
[
  ['major',['major',['../d2/d31/group__Beacon__Major.html',1,'']]],
  ['minor',['minor',['../d3/d76/group__Beacon__Minor.html',1,'']]],
  ['mac',['mac',['../da/ded/group__BLE__MAC.html',1,'']]],
  ['model_20id',['Model ID',['../de/d68/group__Model__ID.html',1,'']]],
  ['misc',['Misc',['../de/de4/group__System__Misc.html',1,'']]]
];
