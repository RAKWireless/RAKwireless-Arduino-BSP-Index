var searchData=
[
  ['binary_2eh',['binary.h',['../d8/da4/binary_8h.html',1,'']]]
];
