var group__DigitalIO =
[
    [ "pinMode", "d8/d8f/group__DigitalIO.html#gabf453c1659ee9fafa5af689523ac71e7", null ],
    [ "digitalWrite", "d8/d8f/group__DigitalIO.html#gae2d36ef66ff3d8970304e7aaf716712d", null ],
    [ "digitalRead", "d8/d8f/group__DigitalIO.html#gab3e9bc73864eb6276f87aa94078224b6", null ]
];