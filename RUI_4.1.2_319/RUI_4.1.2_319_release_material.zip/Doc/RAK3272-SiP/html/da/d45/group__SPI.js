var group__SPI =
[
    [ "SPIClass::begin", "da/d45/group__SPI.html#gab0bdf5cca484fb2ba637c39384b27fb2", null ],
    [ "SPIClass::end", "da/d45/group__SPI.html#gaaf81d3fdaf258088d7692fa70cece087", null ],
    [ "SPIClass::transfer16", "da/d45/group__SPI.html#gab64285a97c97df933ddde227aeeba083", null ],
    [ "SPIClass::transfer", "da/d45/group__SPI.html#ga637803003882effc95f96ea619d4b846", null ],
    [ "SPIClass::beginTransaction", "da/d45/group__SPI.html#ga19c3de3b2fd322add82ff5d95eeed5e2", null ],
    [ "SPIClass::endTransaction", "da/d45/group__SPI.html#gacfca4770169df8cf1f2fedba1f6a6d7d", null ],
    [ "SPIClass::setBitOrder", "da/d45/group__SPI.html#ga8bcea32e400a433fc90dcfc58c4aa6d7", null ],
    [ "SPIClass::setDataMode", "da/d45/group__SPI.html#ga999c08f4599a6121816a34d58d84ab6e", null ],
    [ "SPIClass::setClockDivider", "da/d45/group__SPI.html#ga26aeb088e9f769269751ed7ca2fba198", null ]
];